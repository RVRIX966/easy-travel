import { GoogleGenAI, Type } from "@google/genai";
import { SearchFilters, Destination } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function searchDestinations(filters: SearchFilters): Promise<Destination[]> {
  const prompt = `Suggest 3-5 travel destinations based on these preferences:
  User Budget: $${filters.budget} (Total inclusive)
  User Nationality: ${filters.nationality}
  Travel Preferences: ${filters.preferences.join(', ')}
  
  IMPORTANT CONSTRAINTS:
  1. ALWAYS return 3-5 destinations. NEVER return an empty array.
  2. If the budget is low, prioritize budget-friendly cities or off-season picks.
  3. If no exact matches exist for the budget, suggest the closest matches and denote them as "Great Value".
  4. Include realistic visa protocols for the given nationality.
  5. For each destination, provide 2-3 flight options and 5-8 hotel options.
  6. CRITICAL: The "recommendedHotels" for a destination MUST be strictly located in that destination (city/country). DO NOT include hotels from other locations.
  7. PRICE LIMIT: Every recommended hotel MUST NOT exceed a nightly rate of 1333 USD (which is approximately 5000 SAR).
  
  The response MUST be a JSON array of objects fitting the following schema.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              name: { type: Type.STRING },
              image: { type: Type.STRING, description: "A relevant Unsplash or Picsum URL" },
              type: { type: Type.STRING, description: "e.g. Luxury, Budget, Cultural" },
              price: { type: Type.NUMBER, description: "Total estimated cost" },
              visa: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING },
                  cost: { type: Type.NUMBER },
                  time: { type: Type.STRING }
                },
                required: ["type", "cost", "time"]
              },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              desc: { type: Type.STRING },
              recommendedFlights: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    airline: { type: Type.STRING },
                    code: { type: Type.STRING },
                    class: { type: Type.STRING },
                    price: { type: Type.NUMBER },
                    departure: { type: Type.STRING, description: "City or Airport name" },
                    departureTime: { type: Type.STRING, description: "HH:mm" },
                    depCode: { type: Type.STRING, description: "3-letter code" },
                    arrival: { type: Type.STRING, description: "City or Airport name" },
                    arrivalTime: { type: Type.STRING, description: "HH:mm" },
                    arrCode: { type: Type.STRING, description: "3-letter code" },
                    duration: { type: Type.STRING, description: "e.g. 5h 20m" },
                    stops: { type: Type.INTEGER },
                    logo: { type: Type.STRING, description: "Brand icon URL or Google Favicon URL" }
                  },
                  required: ["id", "airline", "code", "class", "price", "departure", "departureTime", "depCode", "arrival", "arrivalTime", "arrCode", "duration", "stops"]
                }
              },
              recommendedHotels: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    location: { type: Type.STRING },
                    distance: { type: Type.NUMBER, description: "Distance from city center in km" },
                    rating: { type: Type.NUMBER },
                    stars: { type: Type.NUMBER },
                    price: { type: Type.NUMBER, description: "Base price per night" },
                    images: { type: Type.ARRAY, items: { type: Type.STRING } },
                    desc: { type: Type.STRING },
                    amenities: { type: Type.ARRAY, items: { type: Type.STRING } },
                    roomTypes: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          id: { type: Type.STRING },
                          name: { type: Type.STRING },
                          priceMultiplier: { type: Type.NUMBER, description: "multiplier for base price e.g. 1.0, 1.5" },
                          description: { type: Type.STRING }
                        },
                        required: ["id", "name", "priceMultiplier", "description"]
                      }
                    }
                  },
                  required: ["id", "name", "location", "distance", "rating", "stars", "price", "images", "desc", "amenities", "roomTypes"]
                }
              }
            },
            required: ["id", "name", "image", "type", "price", "visa", "tags", "recommendedFlights", "recommendedHotels"]
          }
        }
      }
    });

    const results = JSON.parse(response.text);
    return results;
  } catch (error) {
    console.error("Gemini Search Error:", error);
    throw error;
  }
}
