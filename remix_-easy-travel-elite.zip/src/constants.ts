import { Flight, Hotel } from './types';

export const AIRPORTS = [
  { name: 'Riyadh King Khalid International', city: 'Riyadh', code: 'RUH', country: 'Saudi Arabia' },
  { name: 'Jeddah King Abdulaziz International', city: 'Jeddah', code: 'JED', country: 'Saudi Arabia' },
  { name: 'Dubai International Airport', city: 'Dubai', code: 'DXB', country: 'UAE' },
  { name: 'London Heathrow Airport', city: 'London', code: 'LHR', country: 'United Kingdom' },
  { name: 'Frankfurt Airport', city: 'Frankfurt', code: 'FRA', country: 'Germany' },
  { name: 'Los Angeles International', city: 'Los Angeles', code: 'LAX', country: 'USA' },
  { name: 'Paris Charles de Gaulle', city: 'Paris', code: 'CDG', country: 'France' },
  { name: 'Tokyo Narita Airport', city: 'Tokyo', code: 'NRT', country: 'Japan' },
  { name: 'Singapore Changi Airport', city: 'Singapore', code: 'SIN', country: 'Singapore' },
  { name: 'Istanbul Airport', city: 'Istanbul', code: 'IST', country: 'Turkey' }
];

export const FALLBACK_FLIGHTS: Flight[] = [
  { 
    id: 'f1', 
    airline: 'Saudi Airlines', 
    code: 'SV 123', 
    class: 'Economy', 
    price: 650, 
    departure: 'Riyadh',
    departureTime: '06:00', 
    depCode: 'RUH', 
    arrival: 'London',
    arrivalTime: '11:30', 
    arrCode: 'LHR', 
    duration: '7h 30m',
    stops: 0,
    logo: 'https://www.google.com/s2/favicons?domain=saudia.com&sz=128'
  },
  { 
    id: 'f2', 
    airline: 'Emirates', 
    code: 'EK 201', 
    class: 'Economy', 
    price: 820, 
    departure: 'Dubai',
    departureTime: '08:30', 
    depCode: 'DXB', 
    arrival: 'Paris',
    arrivalTime: '13:05', 
    arrCode: 'CDG', 
    duration: '7h 35m',
    stops: 0,
    logo: 'https://www.google.com/s2/favicons?domain=emirates.com&sz=128'
  },
  { 
    id: 'f3', 
    airline: 'Qatar Airways', 
    code: 'QR 15', 
    class: 'Economy', 
    price: 780, 
    departure: 'Doha',
    departureTime: '07:45', 
    depCode: 'DOH', 
    arrival: 'London',
    arrivalTime: '13:10', 
    arrCode: 'LHR', 
    duration: '7h 25m',
    stops: 1,
    stopDetails: [{ location: 'Doha', duration: '2h 15m' }],
    logo: 'https://www.google.com/s2/favicons?domain=qatarairways.com&sz=128'
  },
  { 
    id: 'f4', 
    airline: 'Turkish Airlines', 
    code: 'TK 1983', 
    class: 'Economy', 
    price: 540, 
    departure: 'Istanbul',
    departureTime: '13:20', 
    depCode: 'IST', 
    arrival: 'London',
    arrivalTime: '15:35', 
    arrCode: 'LHR', 
    duration: '4h 15m',
    stops: 0,
    logo: 'https://www.google.com/s2/favicons?domain=turkishairlines.com&sz=128'
  },
  { 
    id: 'f5', 
    airline: 'Lufthansa', 
    code: 'LH 452', 
    class: 'Economy', 
    price: 920, 
    departure: 'Frankfurt',
    departureTime: '08:45', 
    depCode: 'FRA', 
    arrival: 'Los Angeles',
    arrivalTime: '12:05', 
    arrCode: 'LAX', 
    duration: '11h 20m',
    stops: 1,
    stopDetails: [{ location: 'Munich', duration: '2h 10m' }],
    logo: 'https://www.google.com/s2/favicons?domain=lufthansa.com&sz=128'
  }
];

export const FALLBACK_HOTELS: Hotel[] = [
  { 
    id: 'h1', 
    name: 'Al Faisaliah Hotel', 
    location: 'Riyadh, Saudi Arabia', 
    distance: 0.1,
    rating: 4.9, 
    stars: 5,
    price: 320, // ~1200 SAR
    images: [
      'https://picsum.photos/seed/ryd-fais-1/1200/800', 
      'https://picsum.photos/seed/ryd-fais-2/1200/800'
    ],
    desc: 'An iconic landmark in Riyadh, offering unparalleled luxury and service in the heart of the business district.',
    amenities: ['WiFi', 'Pool', 'Breakfast', 'Gym', 'Spa', 'Butler Service'],
    roomTypes: [
      { id: 'h1-r1', name: 'Superior Room', priceMultiplier: 1, description: 'Spacious room with modern Arabian decor.', images: ['https://picsum.photos/seed/rydr1/800/600'] }
    ]
  },
  { 
    id: 'h2', 
    name: 'The Ritz-Carlton Palace', 
    location: 'Dubai, UAE', 
    distance: 0.5,
    rating: 4.8, 
    stars: 5,
    price: 450, // ~1687 SAR
    images: [
      'https://picsum.photos/seed/dxb-ritz-1/1200/800', 
      'https://picsum.photos/seed/dxb-ritz-2/1200/800'
    ],
    desc: 'An oceanfront oasis in the heart of JBR, featuring sprawling gardens and refined luxury.',
    amenities: ['WiFi', 'Pool', 'Private Beach', 'Breakfast', 'Spa'],
    roomTypes: [
      { id: 'h2-r1', name: 'Deluxe Sea View', priceMultiplier: 1, description: 'Sea view room.', images: ['https://picsum.photos/seed/dxbr1/800/600'] }
    ]
  },
  { 
    id: 'h4', 
    name: 'The Savoy', 
    location: 'London, United Kingdom', 
    distance: 0.1,
    rating: 4.9, 
    stars: 5,
    price: 850, // ~3187 SAR
    images: [
      'https://picsum.photos/seed/lon-savoy-1/1200/800', 
      'https://picsum.photos/seed/lon-savoy-2/1200/800'
    ],
    desc: 'London’s most celebrated hotel on the banks of the Thames.',
    amenities: ['WiFi', 'Butler Service', 'Breakfast', 'Gym'],
    roomTypes: [
      { id: 'h4-r1', name: 'Luxury King', priceMultiplier: 1, description: 'Edwardian style.', images: ['https://picsum.photos/seed/lonr1/800/600'] }
    ]
  },
  { 
    id: 'h7', 
    name: 'The Raj Palace', 
    location: 'Jaipur, India', 
    distance: 1.5,
    rating: 4.9, 
    stars: 5,
    price: 280, // ~1050 SAR
    images: [
      'https://picsum.photos/seed/jai-raj-1/1200/800', 
      'https://picsum.photos/seed/jai-raj-2/1200/800'
    ],
    desc: 'A grand heritage hotel transporting you to the era of Maharajas.',
    amenities: ['WiFi', 'Pool', 'Breakfast', 'Gym'],
    roomTypes: [
      { id: 'h7-r1', name: 'Heritage Room', priceMultiplier: 1, description: 'Traditional decor.', images: ['https://picsum.photos/seed/jair1/800/600'] }
    ]
  },
  { 
    id: 'h8', 
    name: 'Mandapa, a Ritz-Carlton Reserve', 
    location: 'Ubud, Bali, Indonesia', 
    distance: 2.1,
    rating: 5.0, 
    stars: 5,
    price: 750, // ~2812 SAR
    images: [
      'https://picsum.photos/seed/ubd-man-1/1200/800', 
      'https://picsum.photos/seed/ubd-man-2/1200/800'
    ],
    desc: 'A secluded sanctuary alongside the Ayung River in Ubud.',
    amenities: ['WiFi', 'Infinity Pool', 'Spa', 'Yoga'],
    roomTypes: [
      { id: 'h8-r1', name: 'River Front Villa', priceMultiplier: 1, description: 'Private villa.', images: ['https://picsum.photos/seed/ubdr1/800/600'] }
    ]
  },
  { 
    id: 'h12', 
    name: 'Four Seasons Resort Bali', 
    location: 'Jimbaran, Bali, Indonesia', 
    distance: 0.5,
    rating: 4.9, 
    stars: 5,
    price: 900, // ~3375 SAR
    images: [
      'https://picsum.photos/seed/bali-fs-1/1200/800', 
      'https://picsum.photos/seed/bali-fs-2/1200/800'
    ],
    desc: 'Authentic Balinese lifestyle at this all-villa beach resort.',
    amenities: ['WiFi', 'Private Pool', 'Beach Access', 'Spa'],
    roomTypes: [
      { id: 'h12-r1', name: 'Garden View Villa', priceMultiplier: 1, description: 'Tropical garden setting.', images: ['https://picsum.photos/seed/balifsr1/800/600'] }
    ]
  },
  { 
    id: 'h13', 
    name: 'Ayana Resort', 
    location: 'Jimbaran, Bali, Indonesia', 
    distance: 1.2,
    rating: 4.8, 
    stars: 5,
    price: 420, // ~1575 SAR
    images: [
      'https://picsum.photos/seed/bali-ayana-1/1200/800', 
      'https://picsum.photos/seed/bali-ayana-2/1200/800'
    ],
    desc: 'World-class destination resort with stunning clifftop views.',
    amenities: ['WiFi', 'Rock Bar', 'Multiple Pools', 'Spa'],
    roomTypes: [
      { id: 'h13-r1', name: 'Resort View Room', priceMultiplier: 1, description: 'Luxury room with views.', images: ['https://picsum.photos/seed/ayanar1/800/600'] }
    ]
  },
  { 
    id: 'h10-phuket', 
    name: 'Amanpuri', 
    location: 'Phuket, Thailand', 
    distance: 0.1,
    rating: 5.0, 
    stars: 5,
    price: 1100, // ~4125 SAR
    images: [
      'https://picsum.photos/seed/phu-ama-1/1200/800', 
      'https://picsum.photos/seed/phu-ama-2/1200/800'
    ],
    desc: 'Hilltop retreat overlooking the turquoise Andaman Sea.',
    amenities: ['WiFi', 'Private Beach', 'Infinity Pool', 'Library'],
    roomTypes: [
      { id: 'h10-p1-r1', name: 'Ocean Pavilion', priceMultiplier: 1, description: 'Andaman Sea views.', images: ['https://picsum.photos/seed/phur1/800/600'] }
    ]
  },
  { 
    id: 'h14', 
    name: 'Keemala Phuket', 
    location: 'Kamala, Phuket, Thailand', 
    distance: 2.5,
    rating: 4.8, 
    stars: 5,
    price: 650, // ~2437 SAR
    images: [
      'https://picsum.photos/seed/phu-kee-1/1200/800', 
      'https://picsum.photos/seed/phu-kee-2/1200/800'
    ],
    desc: 'A wellness-focused rainforest retreat above Kamala Village.',
    amenities: ['WiFi', 'Private Pool', 'Holistic Spa', 'Gym'],
    roomTypes: [
      { id: 'h14-r1', name: 'Clay Pool Cottage', priceMultiplier: 1, description: 'Unique architecture.', images: ['https://picsum.photos/seed/keer1/800/600'] }
    ]
  },
  { 
    id: 'h10-chiang', 
    name: 'Rayavadee', 
    location: 'Krabi, Thailand', 
    distance: 0.1,
    rating: 4.9, 
    stars: 5,
    price: 580, // ~2175 SAR
    images: [
      'https://picsum.photos/seed/kra-raya-1/1200/800', 
      'https://picsum.photos/seed/kra-raya-2/1200/800'
    ],
    desc: 'Situated at the heart of Krabi’s Phranang Peninsula.',
    amenities: ['WiFi', 'Pool', 'Grotto Dining', 'Spa'],
    roomTypes: [
      { id: 'h10-c1', name: 'Deluxe Pavilion', priceMultiplier: 1, description: 'Lush garden setting.', images: ['https://picsum.photos/seed/rayar1/800/600'] }
    ]
  },
  { 
    id: 'h11', 
    name: 'Lina Ryad & Spa', 
    location: 'Chefchaouen, Morocco', 
    distance: 0.2,
    rating: 4.6, 
    stars: 5,
    price: 190, // ~712 SAR
    images: [
      'https://picsum.photos/seed/che-lina-1/1200/800', 
      'https://picsum.photos/seed/che-lina-2/1200/800'
    ],
    desc: 'Authentic Ryad experience in the blue pearl of Morocco.',
    amenities: ['WiFi', 'Hammam', 'Rooftop Terrace'],
    roomTypes: [
      { id: 'h11-r1', name: 'Standard Suite', priceMultiplier: 1, description: 'Moroccan craftsmanship.', images: ['https://picsum.photos/seed/cher1/800/600'] }
    ]
  },
  { 
    id: 'h-sharm-1', 
    name: 'Four Seasons Resort Sharm El Sheikh', 
    location: 'Sharm El Sheikh, Egypt', 
    distance: 0.1,
    rating: 4.9, 
    stars: 5,
    price: 490, // ~1837 SAR
    images: [
      'https://picsum.photos/seed/sharm-fs-1/1200/800', 
      'https://picsum.photos/seed/sharm-fs-2/1200/800'
    ],
    desc: 'Red Sea luxury at its finest with world-class diving.',
    amenities: ['WiFi', 'Diving Center', 'Pool', 'Spa'],
    roomTypes: [
      { id: 'h-s1-r1', name: 'Sea View Room', priceMultiplier: 1, description: 'Panoramic views of the Red Sea.', images: ['https://picsum.photos/seed/sharmr1/800/600'] }
    ]
  },
  { 
    id: 'h-sharm-2', 
    name: 'Rixos Sharm El Sheikh', 
    location: 'Sharm El Sheikh, Egypt', 
    distance: 2.5,
    rating: 4.8, 
    stars: 5,
    price: 380, // ~1425 SAR
    images: [
      'https://picsum.photos/seed/sharm-rix-1/1200/800', 
      'https://picsum.photos/seed/sharm-rix-2/1200/800'
    ],
    desc: 'Ultra-all-inclusive beach resort on the Nabq Bay.',
    amenities: ['WiFi', 'Water Park', 'Multiple Pools', 'Gym'],
    roomTypes: [
      { id: 'h-s2-r1', name: 'Superior Room', priceMultiplier: 1, description: 'Modern comfort with bay views.', images: ['https://picsum.photos/seed/sharmr2/800/600'] }
    ]
  },
  { 
    id: 'h-cairo-1', 
    name: 'The Nile Ritz-Carlton', 
    location: 'Cairo, Egypt', 
    distance: 0.1,
    rating: 4.8, 
    stars: 5,
    price: 350, // ~1312 SAR
    images: [
      'https://picsum.photos/seed/cairo-rc-1/1200/800', 
      'https://picsum.photos/seed/cairo-rc-2/1200/800'
    ],
    desc: 'Iconic luxury on the banks of the Nile.',
    amenities: ['WiFi', 'Nile View', 'Pool', 'Casino'],
    roomTypes: [
      { id: 'h-c1-r1', name: 'Deluxe City View', priceMultiplier: 1, description: 'Vibrant city views.', images: ['https://picsum.photos/seed/cairor1/800/600'] }
    ]
  }
];
