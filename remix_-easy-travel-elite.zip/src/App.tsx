/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, createContext, useContext } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './views/Home';
import Destinations from './views/Destinations';
import Itinerary from './views/Itinerary';
import Checkout from './views/Checkout';
import Support from './views/Support';
import Auth from './views/Auth';
import MyTrips from './views/MyTrips';
import { AnimatePresence, motion } from 'motion/react';
import { Language, translations } from './lib/translations';
import { SearchFilters, Destination, BookingSummary, User } from './types';

type View = 'home' | 'destinations' | 'itinerary' | 'checkout' | 'support' | 'login' | 'signup' | 'my-trips';

export type Currency = 'USD' | 'SAR' | 'EUR' | 'AED';

export const exchangeRates: Record<Currency, number> = {
  USD: 1,
  SAR: 3.75,
  EUR: 0.94,
  AED: 3.67
};

export const currencySymbols: Record<Currency, string> = {
  USD: '$',
  SAR: 'SAR',
  EUR: '€',
  AED: 'AED'
};

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (cur: Currency) => void;
  formatPrice: (amount: number) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) throw new Error('useCurrency must be used within CurrencyProvider');
  return context;
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};

interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(UserContext);
  if (!context) throw new Error('useAuth must be used within UserProvider');
  return context;
};

export default function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [language, setLanguage] = useState<Language>('en');
  const [currency, setCurrency] = useState<Currency>('SAR');
  const [searchFilters, setSearchFilters] = useState<SearchFilters | null>(null);
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [bookingSummary, setBookingSummary] = useState<BookingSummary | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize Auth from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('et_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Failed to parse saved user", e);
        localStorage.removeItem('et_user');
      }
    }
    setIsInitialized(true);
  }, []);

  // Save user to localStorage on change
  useEffect(() => {
    if (isInitialized) {
      if (user) {
        localStorage.setItem('et_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('et_user');
      }
    }
  }, [user, isInitialized]);

  const logout = () => {
    setUser(null);
    setCurrentView('home');
  };

  const t = translations[language];

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
    setCurrentView('destinations');
  };

  const handleDestinationSelect = (destination: Destination) => {
    setSelectedDestination(destination);
    setCurrentView('itinerary');
  };

  // Scroll to top on view change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentView]);

  // Handle RTL for Arabic
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const formatPrice = (amount: number) => {
    const converted = amount * exchangeRates[currency];
    const symbol = currencySymbols[currency];
    
    // Formatting for display
    return `${symbol} ${converted.toLocaleString(undefined, { 
      maximumFractionDigits: converted < 100 ? 1 : 0,
      minimumFractionDigits: 0
    })}`;
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <motion.div
            key="home"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Home onSearch={handleSearch} />
          </motion.div>
        );
      case 'destinations':
        return (
          <motion.div
            key="destinations"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Destinations 
              initialFilters={searchFilters}
              onSelect={handleDestinationSelect} 
            />
          </motion.div>
        );
      case 'itinerary':
        return (
          <motion.div
            key="itinerary"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Itinerary 
              destination={selectedDestination}
              onComplete={(summary) => {
                setBookingSummary(summary);
                setCurrentView('checkout');
              }} 
            />
          </motion.div>
        );
      case 'checkout':
        if (!user) {
          return (
            <motion.div key="login-redirect" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Auth initialMode="login" onSuccess={() => setCurrentView('checkout')} />
            </motion.div>
          );
        }
        return (
          <motion.div
            key="checkout"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Checkout booking={bookingSummary} onConfirm={() => setCurrentView('my-trips')} />
          </motion.div>
        );
      case 'my-trips':
        if (!user) {
          return (
            <motion.div key="login-redirect-trips" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Auth initialMode="login" onSuccess={() => setCurrentView('my-trips')} />
            </motion.div>
          );
        }
        return (
          <motion.div
            key="my-trips"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <MyTrips />
          </motion.div>
        );
      case 'support':
        return (
          <motion.div
            key="support"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Support />
          </motion.div>
        );
      case 'login':
      case 'signup':
        return (
          <motion.div
            key={currentView}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Auth 
              initialMode={currentView as 'login' | 'signup'} 
              onSuccess={() => setCurrentView('home')} 
            />
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <CurrencyContext.Provider value={{ currency, setCurrency, formatPrice }}>
        <UserContext.Provider value={{ user, setUser, logout }}>
          <div className="min-h-screen bg-background selection:bg-primary/20 selection:text-primary transition-colors duration-500 font-sans">
            <Navbar currentView={currentView} onNavigate={(view) => setCurrentView(view as View)} />
            
            <AnimatePresence mode="wait">
              {isInitialized && renderView()}
            </AnimatePresence>
      
            <Footer />
          </div>
        </UserContext.Provider>
      </CurrencyContext.Provider>
    </LanguageContext.Provider>
  );
}

