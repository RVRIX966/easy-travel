import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-surface-container-low w-full py-16 px-8 mt-24">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-7xl mx-auto">
        <div>
          <div className="text-xl font-bold text-on-surface mb-4">Easy Travel</div>
          <p className="text-on-surface-variant text-sm leading-relaxed max-w-sm">
            © 2024 Easy Travel. Defined by the absence of noise. Every journey starts with a single, well-budgeted step.
          </p>
        </div>
        
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-on-surface/40">Company</h4>
            <div className="space-y-2">
              <a className="block text-on-surface/70 hover:text-primary transition-colors text-sm" href="#">Privacy Policy</a>
              <a className="block text-on-surface/70 hover:text-primary transition-colors text-sm" href="#">Terms of Service</a>
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-on-surface/40">Resources</h4>
            <div className="space-y-2">
              <a className="block text-on-surface/70 hover:text-primary transition-colors text-sm" href="#">Visa Guide</a>
              <a className="block text-on-surface/70 hover:text-primary transition-colors text-sm" href="#">Partner Login</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
