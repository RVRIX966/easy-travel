import React from 'react';
import { Globe, User, Menu, X, Coins, LogOut, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useCurrency, Currency, useAuth } from '../App';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export default function Navbar({ currentView, onNavigate }: NavbarProps) {
  const { language, setLanguage, t } = useLanguage();
  const { currency, setCurrency } = useCurrency();
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const currencies: Currency[] = ['USD', 'SAR', 'EUR', 'AED'];

  const navItems = [
    { id: 'destinations', label: t.nav.destinations },
    { id: 'itinerary', label: t.nav.itineraries },
    { id: 'support', label: t.nav.support }
  ];

  if (user) {
    navItems.splice(2, 0, { id: 'my-trips', label: 'My Trips' });
  }

  const handleLangToggle = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  return (
    <nav className="fixed top-0 w-full z-50 glass-nav ambient-shadow transition-all duration-300">
      <div className="flex justify-between items-center px-8 py-4 max-w-7xl mx-auto">
        <div 
          className="text-2xl font-black tracking-tighter text-on-surface cursor-pointer select-none"
          onClick={() => onNavigate('home')}
        >
          Easy <span className="text-primary italic">Travel</span>
        </div>
        
        <div className="hidden md:flex items-center space-x-10">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "text-xs uppercase tracking-[0.2em] transition-all duration-300 relative py-2 font-black",
                currentView === item.id 
                  ? "text-primary after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-primary"
                  : "text-on-surface/50 hover:text-primary"
              )}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-6">
          <div className="relative group">
            <button 
              className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-on-surface/60 hover:text-primary transition-all border border-outline-variant/20 px-3 py-1.5 rounded-full hover:bg-surface-container-low"
            >
              <Coins className="w-3 h-3" />
              <span>{currency}</span>
            </button>
            <div className="absolute top-full right-0 mt-2 py-2 bg-surface-container-low rounded-xl border border-outline-variant/10 shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              {currencies.map(cur => (
                <button
                  key={cur}
                  onClick={() => setCurrency(cur)}
                  className={cn(
                    "block w-full text-left px-6 py-2 text-[10px] font-black uppercase tracking-widest hover:bg-primary/10 transition-colors",
                    currency === cur ? "text-primary" : "text-on-surface/60"
                  )}
                >
                  {cur}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={handleLangToggle}
            className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-on-surface/60 hover:text-primary transition-all border border-outline-variant/20 px-3 py-1.5 rounded-full hover:bg-surface-container-low"
          >
            <Globe className="w-3 h-3" />
            <span>{language === 'en' ? 'العربية' : 'English'}</span>
          </button>
          
          <div className="flex items-center space-x-5">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black uppercase text-primary tracking-widest">{user.firstName} {user.lastName}</span>
                  <button 
                    onClick={logout}
                    className="flex items-center gap-1 text-[8px] font-black uppercase tracking-widest text-on-surface-variant/40 hover:text-tertiary transition-colors"
                  >
                    <LogOut className="w-2.5 h-2.5" />
                    Sign Out
                  </button>
                </div>
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                  <User className="w-5 h-5 text-primary" />
                </div>
              </div>
            ) : (
              <div 
                className="flex items-center space-x-2 cursor-pointer group"
                onClick={() => onNavigate('login')}
              >
                <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center border border-outline-variant/10 group-hover:bg-primary group-hover:border-primary transition-all">
                  <User className="w-5 h-5 text-on-surface/60 group-hover:text-on-primary" />
                </div>
                <span className="hidden lg:block text-[10px] font-black uppercase tracking-widest text-on-surface/60 group-hover:text-primary">
                  {t.nav.login}
                </span>
              </div>
            )}
            
            <button 
              className="md:hidden p-2 text-on-surface/60"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-surface-container-low border-t border-outline-variant/10 px-8 py-8 space-y-6"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left text-lg font-black text-on-surface/70 hover:text-primary"
              >
                {item.label}
              </button>
            ))}
            <div className="pt-6 border-t border-outline-variant/10">
              {user ? (
                <button 
                  onClick={() => {
                    logout();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-4 bg-tertiary/10 text-tertiary font-black rounded-xl"
                >
                  Logout
                </button>
              ) : (
                <button 
                  onClick={() => {
                    onNavigate('login');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-4 bg-primary text-on-primary font-black rounded-xl shadow-lg"
                >
                  {t.nav.signup}
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
