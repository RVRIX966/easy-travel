import React, { useState, useMemo } from 'react';
import { 
  ChevronDown, ArrowRight, PlaneLanding, Mountain, Landmark, Loader2, 
  Search, Calendar, Users, Briefcase, MapPin, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useCurrency } from '../App';

import { SearchFilters } from '../types';
import { AIRPORTS } from '../constants';

interface HomeProps {
  onSearch: (filters: SearchFilters) => void;
}

export default function Home({ onSearch }: HomeProps) {
  const { t } = useLanguage();
  const { formatPrice } = useCurrency();
  
  // discovery State
  const [budget, setBudget] = useState(2500);
  const [nationality, setNationality] = useState('Saudi Arabia');
  const [selectedPrefs, setSelectedPrefs] = useState<string[]>(['Beach']);
  
  // UI State
  const [isSearching, setIsSearching] = useState(false);

  const preferences = ['Beach', 'Nature', 'City', 'Luxury', 'Culture'];

  const togglePreference = (pref: string) => {
    setSelectedPrefs(prev => 
      prev.includes(pref) 
        ? prev.filter(p => p !== pref) 
        : [...prev, pref]
    );
  };

  const handleSearch = () => {
    if (isSearching) return;
    setIsSearching(true);
    
    const filters: SearchFilters = {
      departure: '', // Not known yet
      tripType: 'round-trip',
      departureDate: new Date().toISOString().split('T')[0],
      passengers: 1,
      cabinClass: 'economy',
      budget,
      nationality,
      preferences: selectedPrefs
    };

    setTimeout(() => {
      setIsSearching(false);
      onSearch(filters);
    }, 1200);
  };

  return (
    <main className="pt-24 overflow-x-hidden min-h-screen bg-surface-container-lowest">
      {/* Hero Content */}
      <section className="relative px-8 py-20 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-12 text-center mb-12"
          >
            <h1 className="text-6xl md:text-8xl font-black leading-[0.9] tracking-tighter text-on-surface mb-8">
              {t.home.heroTitle} <br />
              <span className="text-primary italic font-medium">{t.home.heroSubtitle}</span>
            </h1>
            <p className="text-xl text-on-surface-variant leading-relaxed max-w-2xl mx-auto font-medium opacity-60">
              {t.home.heroDesc}
            </p>
          </motion.div>

          {/* Discovery Panel */}
          <div className="lg:col-span-12 bg-white/50 backdrop-blur-3xl rounded-[3rem] p-12 border border-outline-variant/10 shadow-2xl relative z-20">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 items-end">
              {/* Budget */}
              <div className="space-y-8">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40">{t.home.budgetLabel}</label>
                  <span className="text-3xl font-black text-primary tabular-nums">{formatPrice(budget)}</span>
                </div>
                <div className="bg-surface-container-low p-6 rounded-2xl border border-outline-variant/5">
                  <input 
                    type="range" 
                    min="500" 
                    max="10000" 
                    step="100"
                    value={budget} 
                    onChange={(e) => setBudget(Number(e.target.value))}
                    className="w-full accent-primary h-2 rounded-full appearance-none cursor-pointer"
                  />
                </div>
              </div>

              {/* Nationality */}
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-3 block">{t.home.nationalityLabel}</label>
                <div className="relative group">
                  <select 
                    value={nationality}
                    onChange={(e) => setNationality(e.target.value)}
                    className="w-full bg-surface-container-low border-2 border-transparent hover:border-primary/20 transition-all py-6 px-8 rounded-3xl outline-none font-black text-on-surface appearance-none"
                  >
                    <option>Saudi Arabia</option>
                    <option>United Kingdom</option>
                    <option>United States</option>
                    <option>United Arab Emirates</option>
                    <option>France</option>
                    <option>Japan</option>
                  </select>
                  <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-primary pointer-events-none" />
                </div>
              </div>

              {/* Search Button */}
              <button 
                onClick={handleSearch}
                disabled={isSearching}
                className={cn(
                  "relative py-8 rounded-3xl font-extrabold text-2xl tracking-tighter flex items-center justify-center gap-4 transition-all overflow-hidden group shadow-2xl active:scale-95",
                  isSearching 
                    ? "bg-surface-container-highest cursor-wait" 
                    : "bg-on-background text-white hover:bg-on-background/90"
                )}
              >
                {isSearching ? (
                   <>
                     <Loader2 className="w-8 h-8 animate-spin" />
                     <span>Curating...</span>
                   </>
                ) : (
                  <>
                    <span>{t.home.searchBtn}</span>
                    <ArrowRight className="w-8 h-8 group-hover:translate-x-3 transition-transform" />
                  </>
                )}
              </button>
            </div>

            {/* Preferences */}
            <div className="mt-12 pt-12 border-t border-outline-variant/10">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-6 block">{t.home.prefsLabel}</label>
              <div className="flex flex-wrap gap-3">
                 {preferences.map(p => (
                   <button 
                      key={p}
                      onClick={() => togglePreference(p)}
                      className={cn(
                        "px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest border-2 transition-all active:scale-95",
                        selectedPrefs.includes(p) 
                          ? "bg-primary text-on-primary border-primary shadow-xl" 
                          : "bg-surface-container-low border-transparent text-on-surface-variant/60 hover:border-outline-variant/20"
                      )}
                   >
                     {p}
                   </button>
                 ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-24 px-8 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h3 className="text-[2.5rem] font-black tracking-tighter mb-4">{t.home.featuredTitle}</h3>
            <p className="font-medium text-on-surface-variant/60 max-w-lg">{t.home.featuredDesc}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {[
            { city: 'Kyoto', country: 'Japan', img: 'https://picsum.photos/seed/k1/800/600', code: 'NRT' },
            { city: 'Santorini', country: 'Greece', img: 'https://picsum.photos/seed/s1/800/600', code: 'JTR' },
            { city: 'Dubai', country: 'UAE', img: 'https://picsum.photos/seed/d1/800/600', code: 'DXB' }
          ].map(dest => (
            <motion.div 
               key={dest.city}
               whileHover={{ y: -10 }}
               className="group relative h-[450px] rounded-[3rem] overflow-hidden cursor-pointer shadow-xl"
               onClick={() => handleSearch()}
            >
               <img src={dest.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" referrerPolicy="no-referrer" />
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
               <div className="absolute bottom-12 left-12">
                  <p className="text-[10px] font-black text-primary uppercase tracking-[0.3em] mb-2">{dest.country}</p>
                  <h4 className="text-4xl font-black text-white tracking-tighter">{dest.city}</h4>
               </div>
            </motion.div>
          ))}
        </div>
      </section>
    </main>
  );
}
