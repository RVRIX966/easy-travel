import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User as UserIcon, ArrowRight, Github, Chrome as Google, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useAuth } from '../App';
import { User } from '../types';

interface AuthProps {
  initialMode: 'login' | 'signup';
  onSuccess: () => void;
}

export default function Auth({ initialMode, onSuccess }: AuthProps) {
  const { t } = useLanguage();
  const { setUser } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate auth logic with persistence
    setTimeout(() => {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email,
        firstName: mode === 'signup' ? firstName : 'Explorer',
        lastName: mode === 'signup' ? lastName : 'User',
        joinedAt: new Date().toISOString()
      };
      
      setUser(newUser);
      setIsLoading(false);
      onSuccess();
    }, 1500);
  };

  return (
    <main className="min-h-screen pt-32 pb-20 px-8 flex items-center justify-center bg-surface-container-lowest overflow-hidden relative">
      {/* Decorative Orbs */}
      <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-tertiary/5 rounded-full blur-[120px] pointer-events-none" />

      <motion.div 
        layout
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md z-10"
      >
        <div className="bg-white rounded-[2.5rem] p-12 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.1)] border border-outline-variant/5">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-black tracking-tighter text-on-surface mb-3">
              {mode === 'login' ? t.auth.loginTitle : t.auth.signupTitle}
            </h1>
            <p className="text-on-surface-variant font-medium opacity-60">
              {mode === 'login' ? t.auth.loginDesc : t.auth.signupDesc}
            </p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6">
            {mode === 'signup' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 ml-1">First Name</label>
                  <div className="relative group">
                    <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-outline-variant transition-colors group-focus-within:text-primary" />
                    <input 
                      type="text" 
                      required
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="John"
                      className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl py-4 pl-12 pr-4 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30 text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 ml-1">Last Name</label>
                  <div className="relative group">
                    <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-outline-variant transition-colors group-focus-within:text-primary" />
                    <input 
                      type="text" 
                      required
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="Doe"
                      className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl py-4 pl-12 pr-4 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30 text-sm"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 ml-1">{t.auth.email}</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-outline-variant transition-colors group-focus-within:text-primary" />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="name@company.com"
                  className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl py-4.5 pl-14 pr-6 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-1">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50">{t.auth.password}</label>
                {mode === 'login' && (
                  <button type="button" className="text-[10px] font-black text-primary uppercase tracking-widest hover:opacity-70 transition-opacity">
                    {t.auth.forgotPassword}
                  </button>
                )}
              </div>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-outline-variant transition-colors group-focus-within:text-primary" />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                  className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl py-4.5 pl-14 pr-6 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full py-5 bg-primary text-on-primary rounded-2xl font-black text-lg shadow-xl hover:shadow-[0_20px_40px_-10px_rgba(var(--primary-rgb),0.3)] transition-all active:scale-[0.98] mt-6 flex items-center justify-center gap-3 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <>
                  {mode === 'login' ? t.auth.loginBtn : t.auth.signupBtn}
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          <div className="mt-10">
            <div className="relative flex items-center justify-center mb-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-outline-variant/10"></div>
              </div>
              <span className="relative px-6 bg-white text-[10px] font-black text-on-surface-variant/40 uppercase tracking-[0.3em]">
                {t.auth.orSocial}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center justify-center gap-3 py-4 rounded-xl border border-outline-variant/10 hover:bg-surface-container-low transition-all font-black text-xs uppercase tracking-widest text-on-surface-variant">
                <Google className="w-4 h-4" />
                Google
              </button>
              <button className="flex items-center justify-center gap-3 py-4 rounded-xl border border-outline-variant/10 hover:bg-surface-container-low transition-all font-black text-xs uppercase tracking-widest text-on-surface-variant">
                <Github className="w-4 h-4" />
                Github
              </button>
            </div>
          </div>

          <div className="mt-10 text-center">
            <button 
              onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
              className="text-[11px] font-black uppercase tracking-widest text-on-surface-variant hover:text-primary transition-colors"
            >
              {mode === 'login' ? t.auth.noAccount : t.auth.hasAccount}{' '}
              <span className="text-primary underline underline-offset-4 ml-2">
                {mode === 'login' ? t.auth.signupBtn : t.auth.loginBtn}
              </span>
            </button>
          </div>
        </div>
      </motion.div>
    </main>
  );
}
