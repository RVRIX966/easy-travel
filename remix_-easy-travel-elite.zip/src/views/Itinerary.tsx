import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plane, Hotel, MapPin, Star, Shield, Check, Loader2, Filter, 
  Wifi, Coffee, Waves, Info, X, ChevronLeft, ChevronRight,
  TrendingDown, StarHalf, Navigation, DollarSign, ArrowUpDown,
  Users, Briefcase
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useCurrency } from '../App';
import { Destination, Flight, Hotel as HotelType, RoomType, BookingSummary } from '../types';
import { FALLBACK_FLIGHTS, FALLBACK_HOTELS, AIRPORTS } from '../constants';

interface ItineraryProps {
  destination: Destination | null;
  onComplete: (summary: BookingSummary) => void;
}

type SortOption = 'price_asc' | 'price_desc' | 'rating' | 'distance';

export default function Itinerary({ destination, onComplete }: ItineraryProps) {
  const { t } = useLanguage();
  
  // -- Flight Search State (Moved from Home) --
  const [tripType, setTripType] = useState<'one-way' | 'round-trip'>('round-trip');
  const [departure, setDeparture] = useState('');
  const [depDate, setDepDate] = useState(new Date().toISOString().split('T')[0]);
  const [retDate, setRetDate] = useState(new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]);
  const [passengers, setPassengers] = useState(1);
  const [cabinClass, setCabinClass] = useState<'economy' | 'premium' | 'business' | 'first'>('economy');
  const [activeInput, setActiveInput] = useState<boolean>(false);
  const [isSearchingFlights, setIsSearchingFlights] = useState(false);
  const [flightSearchPerformed, setFlightSearchPerformed] = useState(false);

  // Data sources
  const [flights, setFlights] = useState<Flight[]>([]);
  
  // Max nightly budget in USD (5000 SAR / 3.75 ≈ 1333 USD)
  const MAX_HOTEL_USD = 1333;

  const initialHotels = useMemo(() => {
    if (destination?.recommendedHotels && destination.recommendedHotels.length > 0) {
      return destination.recommendedHotels;
    }
    
    if (!destination) return [];

    const nameParts = (destination?.name || '').split(',').map(p => p.trim().toLowerCase());
    
    return FALLBACK_HOTELS.filter(h => {
      const hotelLoc = h.location.toLowerCase();
      const hotelName = h.name.toLowerCase();
      
      // Strict filtering logic:
      // The first part (city/island) MUST match.
      const matchesMainPart = hotelLoc.includes(nameParts[0]) || hotelName.includes(nameParts[0]);
      
      // If there's a second part (country/region), it must also be part of the location to avoid cross-country confusion
      // (though matchesMainPart is usually enough, this adds safety)
      const matchesSecondaryPart = nameParts.length > 1 ? hotelLoc.includes(nameParts[1]) : true;

      return matchesMainPart && matchesSecondaryPart;
    });
  }, [destination]);

  // Selection state
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [selectedHotel, setSelectedHotel] = useState<HotelType | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<RoomType | null>(null);
  const [roomCount, setRoomCount] = useState(1);
  const [checkInDate, setCheckInDate] = useState(depDate);
  const [checkOutDate, setCheckOutDate] = useState(retDate);
  const [hotelOptions, setHotelOptions] = useState<{breakfast: boolean}>({ breakfast: false });

  const handleNightsChange = (change: number) => {
    const start = new Date(checkInDate);
    const currentNights = Math.ceil(Math.abs(new Date(checkOutDate).getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) || 1;
    const newNights = Math.max(1, currentNights + change);
    const newEnd = new Date(start);
    newEnd.setDate(start.getDate() + newNights);
    setCheckOutDate(newEnd.toISOString().split('T')[0]);
  };
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);

  // Scroll to top when moving between steps (Flight -> Hotel)
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentStep]);

  // Filter & Sort state
  const [sortBy, setSortBy] = useState<SortOption>('price_asc');
  const [flightSortBy, setFlightSortBy] = useState<'price' | 'duration' | 'stops'>('price');
  const [flightFilters, setFlightFilters] = useState({
    maxPrice: 5000,
    maxStops: 2,
    airlines: [] as string[]
  });
  const [hotelFilters, setHotelFilters] = useState({
    minStars: 0,
    maxPrice: MAX_HOTEL_USD,
    amenities: [] as string[]
  });

  // Modal State
  const [detailHotel, setDetailHotel] = useState<HotelType | null>(null);

  // Handle body scroll locking when modal is open
  useEffect(() => {
    if (detailHotel) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [detailHotel]);
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  const allAmenities = ['WiFi', 'Pool', 'Breakfast', 'Gym', 'Spa', 'Parking'];

  const { formatPrice } = useCurrency();

  // Sync selections if destination changes
  useEffect(() => {
    setSelectedFlight(null);
    setSelectedHotel(null);
    setSelectedRoom(null);
    setFlights([]);
    setFlightSearchPerformed(false);
    // Sync hotel dates with flight dates initially
    setCheckInDate(depDate);
    setCheckOutDate(retDate);
    // Reset filters to defaults for new destination
    setHotelFilters({
      minStars: 0,
      maxPrice: MAX_HOTEL_USD,
      amenities: []
    });
  }, [destination, MAX_HOTEL_USD]);

  const filteredAirports = useMemo(() => {
    if (!departure || departure.length < 2) return [];
    return AIRPORTS.filter(a => 
      a.city.toLowerCase().includes(departure.toLowerCase()) || 
      a.code.toLowerCase().includes(departure.toLowerCase()) ||
      a.name.toLowerCase().includes(departure.toLowerCase())
    ).slice(0, 5);
  }, [departure]);

  const handleFlightSearch = () => {
    if (!departure) return;
    setIsSearchingFlights(true);
    // Simulate API call or use gemini
    setTimeout(() => {
      setFlights(destination?.recommendedFlights || FALLBACK_FLIGHTS);
      setIsSearchingFlights(false);
      setFlightSearchPerformed(true);
      // Scroll to flight results
      document.getElementById('flight-results')?.scrollIntoView({ behavior: 'smooth' });
    }, 1500);
  };

  const sortedAndFilteredFlights = useMemo(() => {
    let result = [...flights].filter(f => {
      const matchPrice = f.price <= flightFilters.maxPrice;
      const matchStops = f.stops <= flightFilters.maxStops;
      const matchAirline = flightFilters.airlines.length === 0 || flightFilters.airlines.includes(f.airline);
      return matchPrice && matchStops && matchAirline;
    });

    result.sort((a, b) => {
      if (flightSortBy === 'price') return a.price - b.price;
      if (flightSortBy === 'duration') {
        const getMinutes = (d: string) => {
          const hours = parseInt(d.match(/(\d+)h/)?.[1] || '0');
          const mins = parseInt(d.match(/(\d+)m/)?.[1] || '0');
          return hours * 60 + mins;
        };
        return getMinutes(a.duration) - getMinutes(b.duration);
      }
      if (flightSortBy === 'stops') return a.stops - b.stops;
      return 0;
    });

    return result;
  }, [flights, flightFilters, flightSortBy]);

  const uniqueAirlines = useMemo(() => {
    const set = new Set(flights.map(f => f.airline));
    return Array.from(set);
  }, [flights]);

  const sortedAndFilteredHotels = useMemo(() => {
    let result = [...initialHotels].filter(h => {
      const matchStars = h.stars >= hotelFilters.minStars;
      const matchPrice = h.price <= hotelFilters.maxPrice;
      const matchAmenities = hotelFilters.amenities.every(a => h.amenities?.includes(a));
      return matchStars && matchPrice && matchAmenities;
    });

    result.sort((a, b) => {
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'distance') return (a.distance || 0) - (b.distance || 0);
      return 0;
    });

    return result;
  }, [initialHotels, hotelFilters, sortBy]);

  const stats = useMemo(() => {
    const flightPrice = selectedFlight ? selectedFlight.price * passengers : 0;
    const hotelBase = selectedHotel ? selectedHotel.price : 0;
    const roomMultiplier = selectedRoom ? selectedRoom.priceMultiplier : 1;
    
    // Calculate nights dynamically
    const start = new Date(checkInDate);
    const end = new Date(checkOutDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const nightsCount = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
    
    const hotelTotal = (hotelBase * roomMultiplier) * nightsCount * roomCount;
    const optionsPrice = hotelOptions.breakfast ? 45 * nightsCount * roomCount : 0;
    
    const subtotal = flightPrice + hotelTotal + optionsPrice;
    const taxes = Math.round(subtotal * 0.05);
    const total = subtotal + taxes;
    
    return { flightPrice, hotelTotal, optionsPrice, taxes, total, nights: nightsCount };
  }, [selectedFlight, selectedHotel, selectedRoom, hotelOptions, roomCount, passengers, checkInDate, checkOutDate]);

  const handleComplete = () => {
    if (!selectedFlight || !selectedHotel) return;
    setIsProcessing(true);

    const summary: BookingSummary = {
      flight: selectedFlight,
      hotel: selectedHotel,
      room: selectedRoom,
      passengers,
      roomCount,
      nights: stats.nights,
      checkInDate,
      checkOutDate,
      breakfast: hotelOptions.breakfast,
      totalPrice: stats.total,
      taxes: stats.taxes
    };

    setTimeout(() => {
      setIsProcessing(false);
      onComplete(summary);
    }, 1500);
  };

  const toggleFlightAirline = (airline: string) => {
    setFlightFilters(prev => ({
      ...prev,
      airlines: prev.airlines.includes(airline)
        ? prev.airlines.filter(a => a !== airline)
        : [...prev.airlines, airline]
    }));
  };

  const toggleAmenity = (a: string) => {
    setHotelFilters(prev => ({
      ...prev,
      amenities: prev.amenities.includes(a) 
        ? prev.amenities.filter(item => item !== a)
        : [...prev.amenities, a]
    }));
  };

  const openDetails = (hotel: HotelType) => {
    setDetailHotel(hotel);
    setActiveImageIdx(0);
  };

  const selectHotel = (hotel: HotelType, room?: RoomType) => {
    setSelectedHotel(hotel);
    setSelectedRoom(room || hotel.roomTypes?.[0] || null);
    setDetailHotel(null);
  };

  return (
    <main className="pt-24 pb-32 px-6 max-w-7xl mx-auto min-h-screen">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Main Flow */}
        <div className="lg:col-span-8 space-y-32">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-16 border-b border-outline-variant/10 pb-16"
          >
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-primary/10 text-primary px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
                Trip Customization
              </span>
              <span className="text-on-surface-variant/40 font-black text-[10px] uppercase tracking-widest">
                {destination?.name || 'Explore Destinations'}
              </span>
            </div>
            <h1 className="text-6xl font-black text-on-surface tracking-tighter max-w-2xl leading-[0.9]">
              Craft Your Perfect Journey.
            </h1>
          </motion.div>

          <div className="flex items-center gap-4 mb-12 bg-surface-container-low p-2 rounded-3xl border border-outline-variant/10 w-fit">
            <button 
              onClick={() => setCurrentStep(1)}
              className={cn(
                "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3",
                currentStep === 1 ? "bg-primary text-on-primary shadow-xl" : "text-on-surface-variant hover:bg-surface-container-high"
              )}
            >
              <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center text-[8px]", currentStep === 1 ? "border-on-primary bg-on-primary text-primary" : "border-outline-variant")}>1</div>
              Flights
            </button>
            <div className="w-8 h-[2px] bg-outline-variant/20" />
            <button 
              onClick={() => selectedFlight && setCurrentStep(2)}
              disabled={!selectedFlight}
              className={cn(
                "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3 disabled:opacity-30 disabled:cursor-not-allowed",
                currentStep === 2 ? "bg-primary text-on-primary shadow-xl" : "text-on-surface-variant hover:bg-surface-container-high"
              )}
            >
              <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center text-[8px]", currentStep === 2 ? "border-on-primary bg-on-primary text-primary" : "border-outline-variant")}>2</div>
              Hotels
            </button>
          </div>

          <AnimatePresence mode="wait">
            {currentStep === 1 ? (
              <motion.div 
                key="step-flights"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-32"
              >
                {/* Flight Configuration */}
                <section id="flights" className="scroll-mt-32">
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="mb-12"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-primary font-black tracking-[0.2em] text-[0.7rem] uppercase">Protocol 01</span>
                      <div className="h-[1px] w-12 bg-primary/20" />
                    </div>
                    <h2 className="text-4xl font-black text-on-surface tracking-tighter">{t.itinerary.flights}</h2>
                    <p className="text-on-surface-variant mt-3 text-lg font-medium opacity-60">Connect to {destination?.name} from your origin.</p>
                  </motion.div>

            {/* Search Form */}
            <div className="bg-surface-container-low p-10 rounded-[3rem] border border-outline-variant/10 shadow-xl mb-16 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Plane className="w-32 h-32 rotate-45" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative z-10">
                {/* Trip Type & Class */}
                <div className="md:col-span-2 flex flex-wrap items-center gap-8 mb-4">
                  <div className="flex bg-white/50 p-1.5 rounded-2xl shadow-sm border border-outline-variant/10">
                    <button 
                      onClick={() => setTripType('round-trip')}
                      className={cn(
                        "px-6 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all",
                        tripType === 'round-trip' ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:text-on-surface"
                      )}
                    >
                      Round Trip
                    </button>
                    <button 
                      onClick={() => setTripType('one-way')}
                      className={cn(
                        "px-6 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all",
                        tripType === 'one-way' ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:text-on-surface"
                      )}
                    >
                      One Way
                    </button>
                  </div>

                  <div className="flex items-center gap-8">
                    <div className="relative group">
                      <Users className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-primary pointer-events-none" />
                      <select 
                        value={passengers}
                        onChange={(e) => setPassengers(Number(e.target.value))}
                        className="bg-transparent text-xs font-black text-on-surface outline-none cursor-pointer appearance-none pl-6 pr-4"
                      >
                        {[1,2,3,4,5,6].map(n => <option key={n} value={n}>{n} traveler{n > 1 ? 's' : ''}</option>)}
                      </select>
                    </div>

                    <div className="w-[1px] h-4 bg-outline-variant/20" />

                    <div className="relative group">
                      <Briefcase className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-primary pointer-events-none" />
                      <select 
                        value={cabinClass}
                        onChange={(e) => setCabinClass(e.target.value as any)}
                        className="bg-transparent text-xs font-black text-on-surface outline-none cursor-pointer appearance-none pl-6 pr-4"
                      >
                        <option value="economy">Economy</option>
                        <option value="premium">Premium</option>
                        <option value="business">Business</option>
                        <option value="first">First</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Locations */}
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-1 block">Traveling From</label>
                  <div className="relative group">
                    <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-primary/40 group-focus-within:text-primary transition-colors" />
                    <input 
                      type="text"
                      value={departure}
                      onChange={(e) => { setDeparture(e.target.value); setActiveInput(true); }}
                      onFocus={() => setActiveInput(true)}
                      placeholder="Departure City or Code"
                      className="w-full bg-white/50 border-2 border-transparent focus:border-primary/20 transition-all py-5 px-14 rounded-3xl outline-none font-black text-on-surface placeholder:text-on-surface-variant/20"
                    />
                    
                    {/* Autocomplete */}
                    <AnimatePresence>
                      {activeInput && filteredAirports.length > 0 && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className="absolute top-24 left-0 right-0 bg-white shadow-2xl rounded-3xl border border-outline-variant/10 z-[60] overflow-hidden"
                        >
                          {filteredAirports.map(a => (
                            <button 
                              key={a.code}
                              onClick={() => { setDeparture(`${a.city} (${a.code})`); setActiveInput(false); }}
                              className="w-full text-left p-4 hover:bg-primary/5 flex items-center justify-between group transition-colors border-b border-outline-variant/5 last:border-0"
                            >
                              <div className="flex items-center gap-4">
                                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-black text-[10px]">{a.code}</div>
                                <div>
                                  <p className="font-black text-on-surface text-sm leading-none mb-1">{a.city}</p>
                                  <p className="text-[8px] font-bold text-on-surface-variant/40 uppercase tracking-widest">{a.name}</p>
                                </div>
                              </div>
                              <ArrowUpDown className="w-4 h-4 text-primary/20 rotate-90" />
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-1 block">Traveling To</label>
                  <div className="relative group grayscale">
                    <Navigation className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-primary/40" />
                    <input 
                      type="text"
                      value={destination?.name || ''}
                      readOnly
                      className="w-full bg-white/30 border-2 border-transparent py-5 px-14 rounded-3xl outline-none font-black text-on-surface-variant/50 cursor-default"
                    />
                  </div>
                </div>

                {/* Date Selection */}
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-1 block">Departure Date</label>
                  <div className="relative group">
                    <input 
                      type="date"
                      value={depDate}
                      onChange={(e) => {
                        const newDep = e.target.value;
                        setDepDate(newDep);
                        // If return date is before new departure, adjust it
                        if (retDate < newDep) {
                          setRetDate(newDep);
                        }
                      }}
                      className="w-full bg-white/50 border-2 border-transparent focus:border-primary/20 transition-all py-5 px-8 rounded-3xl outline-none font-black text-on-surface"
                    />
                  </div>
                </div>

                <AnimatePresence>
                  {tripType === 'round-trip' && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-4 overflow-hidden"
                    >
                      <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/40 mb-1 block">Return Date</label>
                      <div className="relative group">
                        <input 
                          type="date"
                          value={retDate}
                          min={depDate}
                          onChange={(e) => setRetDate(e.target.value)}
                          className="w-full bg-white/50 border-2 border-transparent focus:border-primary/20 transition-all py-5 px-8 rounded-3xl outline-none font-black text-on-surface"
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="md:col-span-2 pt-6">
                  <button 
                    onClick={handleFlightSearch}
                    disabled={isSearchingFlights || !departure}
                    className={cn(
                      "w-full py-7 rounded-[2rem] font-black text-2xl tracking-tighter flex items-center justify-center gap-4 transition-all shadow-xl active:scale-95",
                      isSearchingFlights ? "bg-surface-container-highest cursor-wait" : "bg-primary text-on-primary hover:bg-primary/90"
                    )}
                  >
                    {isSearchingFlights ? (
                      <>
                        <Loader2 className="w-8 h-8 animate-spin" />
                        <span>Fetching Flight Options...</span>
                      </>
                    ) : (
                      <>
                        <span>Search Available Transports</span>
                        <Plane className="w-8 h-8" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Flight Results */}
            <div id="flight-results" className="scroll-mt-32">
              <AnimatePresence>
                {flightSearchPerformed && (
                  <motion.div 
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-12"
                  >
                    {/* Header for results */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-outline-variant/5 pb-8">
                       <div>
                         <h3 className="text-2xl font-black text-on-surface tracking-tight">Available Transports</h3>
                         <p className="text-on-surface-variant text-xs font-medium opacity-60">Found {sortedAndFilteredFlights.length} variants matching your criteria.</p>
                       </div>
                       
                       <div className="flex flex-wrap items-center gap-4">
                         <div className="relative group">
                           <select 
                             value={flightSortBy}
                             onChange={(e) => setFlightSortBy(e.target.value as any)}
                             className="bg-surface-container-low px-6 py-3 rounded-2xl border border-outline-variant/10 text-[10px] font-black uppercase tracking-widest outline-none appearance-none pr-10"
                           >
                             <option value="price">Cheapest</option>
                             <option value="duration">Fastest</option>
                             <option value="stops">Direct</option>
                           </select>
                           <ArrowUpDown className="absolute right-4 top-1/2 -translate-y-1/2 w-3 h-3 text-primary pointer-events-none" />
                         </div>
                       </div>
                    </div>

                    {/* Flight List */}
                    <div className="space-y-6">
                       {sortedAndFilteredFlights.map(flight => (
                         <motion.div 
                           key={flight.id}
                           layout
                           onClick={() => setSelectedFlight(flight)}
                           className={cn(
                             "relative p-8 rounded-[2.5rem] border transition-all duration-500 cursor-pointer ambient-shadow overflow-hidden group/card",
                             selectedFlight?.id === flight.id 
                               ? "bg-surface-container-lowest border-primary ring-2 ring-primary/10" 
                               : "bg-surface-container-low border-outline-variant/10 hover:border-outline-variant/40"
                           )}
                         >
                           <div className="flex flex-col md:flex-row justify-between items-center gap-10 relative z-10">
                              {/* Carrier */}
                              <div className="flex items-center gap-6 min-w-[200px]">
                                <div className={cn(
                                  "w-16 h-16 rounded-2xl flex items-center justify-center transition-all bg-white shadow-inner border",
                                  selectedFlight?.id === flight.id ? "border-primary/20" : "border-outline-variant/5"
                                )}>
                                  {flight.logo ? (
                                    <img src={flight.logo} className="w-10 h-10 object-contain" referrerPolicy="no-referrer" />
                                  ) : (
                                    <Plane className="w-7 h-7" />
                                  )}
                                </div>
                                <div>
                                  <p className="font-black text-on-surface transition-colors group-hover/card:text-primary leading-none text-lg mb-1">{flight.airline}</p>
                                  <p className="text-[10px] uppercase font-bold text-on-surface-variant/40 tracking-widest">{flight.code} • {flight.class}</p>
                                </div>
                              </div>

                              {/* Timeline */}
                              <div className="flex-1 flex items-center justify-center gap-10 w-full">
                                <div className="text-right">
                                  <p className="text-3xl font-black tabular-nums leading-none mb-1">{flight.departureTime}</p>
                                  <p className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest">{flight.depCode}</p>
                                </div>

                                  <div className="flex flex-col items-center flex-1 max-w-[150px]">
                                  <span className="text-[9px] text-on-surface-variant/40 uppercase font-black tracking-widest mb-2">{flight.duration}</span>
                                  <div className="w-full h-[1px] bg-outline-variant/20 relative">
                                    <div className={cn(
                                      "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full transition-all",
                                      selectedFlight?.id === flight.id ? "bg-primary" : "bg-outline-variant"
                                    )} />
                                  </div>
                                  <span className="text-[9px] font-black text-primary uppercase mt-2">
                                    {flight.stops === 0 ? 'Direct' : (
                                      <span className="flex items-center gap-1">
                                        {flight.stops} Stop{flight.stops > 1 ? 's' : ''}
                                        {flight.stopDetails?.[0] && (
                                          <span className="text-[8px] opacity-40 lowercase">({flight.stopDetails[0].duration} in {flight.stopDetails[0].location})</span>
                                        )}
                                      </span>
                                    )}
                                  </span>
                                </div>

                                <div>
                                  <p className="text-3xl font-black tabular-nums leading-none mb-1">{flight.arrivalTime}</p>
                                  <p className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest">{flight.arrCode}</p>
                                </div>
                              </div>

                              {/* Pricing */}
                              <div className="flex flex-col items-end min-w-[120px]">
                                <p className={cn(
                                  "text-4xl font-black tabular-nums tracking-tighter",
                                  selectedFlight?.id === flight.id ? "text-primary" : "text-on-surface"
                                )}>{formatPrice(flight.price)}</p>
                                <p className="text-[9px] font-black text-on-surface-variant/40 uppercase tracking-widest">Total Fare</p>
                              </div>
                           </div>
                         </motion.div>
                       ))}
                    </div>

                    {sortedAndFilteredFlights.length === 0 && (
                      <div className="py-20 text-center border-2 border-dashed border-outline-variant/10 rounded-[2.5rem]">
                        <p className="text-on-surface-variant font-black">No flights match the current synthesized filters.</p>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
              
              {!flightSearchPerformed && !isSearchingFlights && (
                <div className="py-20 text-center border-2 border-dashed border-outline-variant/10 rounded-[3rem] opacity-40">
                   <Plane className="w-12 h-12 mx-auto mb-6 text-primary" />
                   <p className="text-sm font-black uppercase tracking-widest">Awaiting Transport Configuration</p>
                   <p className="text-xs font-medium mt-2">Specify your origin and dates above to discover available routes.</p>
                </div>
              )}
            </div>

            {selectedFlight && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="pt-12 flex justify-center"
              >
                <button 
                  onClick={() => setCurrentStep(2)}
                  className="bg-primary text-on-primary px-12 py-6 rounded-[2rem] font-black text-xl tracking-tight shadow-2xl hover:translate-y-[-4px] active:translate-y-0 transition-all flex items-center gap-4 group"
                >
                  Confirm Transport & Continue to Hotels
                  <ArrowUpDown className="w-5 h-5 rotate-90 opacity-40 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            )}
          </section>
        </motion.div>
      ) : (
        <motion.div 
          key="step-hotels"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="space-y-32"
        >
          {/* Hotel Selection */}
          <section id="hotels">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-12"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-primary font-black tracking-[0.2em] text-[0.7rem] uppercase">Step 02</span>
                <div className="h-[1px] w-12 bg-primary/20" />
              </div>
              <h2 className="text-4xl font-black text-on-surface tracking-tighter">{t.itinerary.hotels}</h2>
              <p className="text-on-surface-variant mt-3 text-lg font-medium opacity-60">Superior stays, tailored to your refinement.</p>
            </motion.div>

            {/* Hotel Controls */}
            <div className="bg-surface-container-low p-10 rounded-[2.5rem] border border-outline-variant/10 mb-16 ambient-shadow space-y-12">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 block">Check-in Date</label>
                  <input 
                    type="date"
                    value={checkInDate}
                    min={depDate}
                    max={retDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    className="w-full bg-surface-container-lowest p-5 rounded-2xl border border-outline-variant/10 font-bold text-on-surface outline-none focus:ring-4 focus:ring-primary/10 transition-all"
                  />
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 block">Check-out Date</label>
                  <input 
                    type="date"
                    value={checkOutDate}
                    min={checkInDate}
                    max={retDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                    className="w-full bg-surface-container-lowest p-5 rounded-2xl border border-outline-variant/10 font-bold text-on-surface outline-none focus:ring-4 focus:ring-primary/10 transition-all"
                  />
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 block">Stay Duration</label>
                  <div className="flex bg-surface-container-lowest rounded-2xl border border-outline-variant/10 overflow-hidden">
                    <button 
                      onClick={() => handleNightsChange(-1)}
                      className="px-6 py-5 hover:bg-surface-container-highest transition-colors font-black text-xl text-primary"
                    >-</button>
                    <div className="flex-1 flex flex-col items-center justify-center font-black">
                      <span className="text-primary text-lg">{stats.nights}</span>
                      <span className="text-[8px] uppercase tracking-tighter text-on-surface-variant/40 leading-none">Nights</span>
                    </div>
                    <button 
                      onClick={() => handleNightsChange(1)}
                      className="px-6 py-5 hover:bg-surface-container-highest transition-colors font-black text-xl text-primary"
                    >+</button>
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 block">Room Count</label>
                  <div className="flex bg-surface-container-lowest rounded-2xl border border-outline-variant/10 overflow-hidden">
                    <button 
                      onClick={() => setRoomCount(Math.max(1, roomCount - 1))}
                      className="px-6 py-5 hover:bg-surface-container-highest transition-colors font-black text-xl text-primary"
                    >-</button>
                    <div className="flex-1 flex items-center justify-center font-black text-on-surface text-lg">
                      {roomCount}
                    </div>
                    <button 
                      onClick={() => setRoomCount(roomCount + 1)}
                      className="px-6 py-5 hover:bg-surface-container-highest transition-colors font-black text-xl text-primary"
                    >+</button>
                  </div>
                </div>
              </div>

              <div className="flex flex-col lg:flex-row gap-12 items-start pt-8 border-t border-outline-variant/5">
                <div className="flex-1 w-full lg:w-auto min-w-[280px]">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6 block">Max Nightly Rate</label>
                  <div className="space-y-6">
                    <input 
                      type="range" 
                      min="50" 
                      max={MAX_HOTEL_USD} 
                      step="10"
                      value={hotelFilters.maxPrice}
                      onChange={(e) => setHotelFilters({...hotelFilters, maxPrice: Number(e.target.value)})}
                      className="w-full accent-primary h-2 bg-surface-container-high rounded-full appearance-none cursor-pointer block"
                    />
                    <div className="flex flex-col gap-1.5">
                      <span className="font-black text-primary text-3xl tracking-tighter tabular-nums leading-none">
                        {formatPrice(hotelFilters.maxPrice)}
                      </span>
                      <p className="text-[10px] text-on-surface-variant/40 font-black uppercase tracking-[0.1em]">
                        Maximum limit: {formatPrice(MAX_HOTEL_USD)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="w-full lg:w-auto">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6 block">Minimum stars</label>
                  <div className="flex gap-2">
                    {[3, 4, 5].map(s => (
                      <button 
                        key={s}
                        onClick={() => setHotelFilters({...hotelFilters, minStars: s === hotelFilters.minStars ? 0 : s})}
                        className={cn(
                          "w-14 h-14 rounded-2xl border-2 font-black transition-all flex items-center justify-center gap-1",
                          hotelFilters.minStars === s 
                            ? "bg-primary text-on-primary border-primary shadow-xl" 
                            : "bg-surface-container-lowest border-outline-variant/10 text-on-surface-variant hover:border-primary/30"
                        )}
                      >
                        {s} <Star className="w-3 h-3" fill={hotelFilters.minStars === s ? "currentColor" : "none"} />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1 w-full lg:w-auto min-w-[240px]">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6 block">Selection Order</label>
                  <div className="relative group">
                    <select 
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as SortOption)}
                      className="w-full bg-surface-container-lowest p-5 rounded-2xl border border-outline-variant/10 outline-none focus:ring-4 focus:ring-primary/10 text-on-surface font-black cursor-pointer appearance-none px-8 text-sm"
                    >
                      <option value="price_asc">Price: Low to High</option>
                      <option value="price_desc">Price: High to Low</option>
                      <option value="rating">Guest Rating: Best First</option>
                      <option value="distance">Proximity to Center</option>
                    </select>
                    <ArrowUpDown className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-primary w-4 h-4" />
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-outline-variant/5">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-4 block">Essential Amenities</label>
                <div className="flex flex-wrap gap-3">
                  {allAmenities.map(a => (
                    <button 
                      key={a}
                      onClick={() => toggleAmenity(a)}
                      className={cn(
                        "px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all active:scale-95 flex items-center gap-2",
                        hotelFilters.amenities.includes(a) 
                          ? "bg-primary/10 border-primary text-primary shadow-inner" 
                          : "bg-surface-container-lowest border-outline-variant/10 text-on-surface-variant hover:bg-surface-container-lowest hover:border-outline-variant/60"
                      )}
                    >
                      {hotelFilters.amenities.includes(a) && <Check className="w-3 h-3" />}
                      {a}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <AnimatePresence mode="popLayout">
                {sortedAndFilteredHotels.length > 0 ? (
                  sortedAndFilteredHotels.map((hotel) => (
                    <motion.div 
                      key={hotel.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={cn(
                        "group bg-surface-container-lowest rounded-[2.5rem] overflow-hidden border transition-all duration-500 ambient-shadow-lg flex flex-col hover:shadow-2xl",
                        selectedHotel?.id === hotel.id 
                          ? "ring-2 ring-primary border-primary shadow-primary/10" 
                          : "border-outline-variant/10"
                      )}
                    >
                      <div className="h-64 relative overflow-hidden cursor-pointer" onClick={() => openDetails(hotel)}>
                        <img 
                          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
                          src={hotel.images[0]} 
                          alt={hotel.name}
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-6 left-6 flex gap-2">
                          <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center shadow-lg border border-white/20">
                            <Star className="w-3 h-3 text-tertiary fill-current" />
                            <span className="text-[10px] font-black text-on-surface-variant ml-1">{hotel.rating}</span>
                          </div>
                          {hotel.tag && (
                            <div className="bg-primary px-3 py-1.5 rounded-full text-[9px] font-black text-on-primary uppercase tracking-widest shadow-lg">
                              {hotel.tag}
                            </div>
                          )}
                        </div>
                        <div className="absolute bottom-6 left-6">
                          <div className="bg-primary/90 backdrop-blur-md px-3 py-1.5 rounded-lg text-[9px] font-black text-white uppercase tracking-tighter border border-white/20">
                            Stay Protection Active
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-8 flex flex-1 flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start mb-6">
                            <div className="flex-1 mr-4">
                              <h3 className="text-2xl font-black text-on-surface tracking-tighter leading-tight group-hover:text-primary transition-colors mb-2">{hotel.name}</h3>
                              <div className="flex gap-0.5">
                                {Array.from({ length: hotel.stars }).map((_, i) => (
                                  <Star key={i} className="w-2.5 h-2.5 text-primary fill-current" />
                                ))}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40 mb-1">Nightly From</div>
                              <div className="text-2xl font-black text-primary tracking-tighter">{formatPrice(hotel.price)}</div>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-x-6 gap-y-4 mb-8 text-on-surface-variant/60 font-medium text-xs">
                             <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-primary" /> {hotel.location}</span>
                             <span className="flex items-center gap-1.5"><Navigation className="w-4 h-4 text-primary" /> {hotel.distance}km</span>
                             <div className="flex-1 min-w-[10px]" />
                             <div className="flex flex-col items-end border-l border-outline-variant/10 pl-6">
                               <span className="text-[9px] font-black text-primary uppercase mb-1">Stay Estimate ({stats.nights} nights)</span>
                               <span className="text-lg font-black text-on-surface tabular-nums">{formatPrice(hotel.price * stats.nights)}</span>
                             </div>
                          </div>

                          <div className="flex flex-wrap gap-2 mb-8">
                            {hotel.amenities.slice(0, 3).map(a => (
                              <span key={a} className="text-[9px] font-black uppercase tracking-widest px-2 py-1 bg-surface-container-high rounded text-on-surface-variant/70">{a}</span>
                            ))}
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <button 
                            onClick={() => openDetails(hotel)}
                            className="flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest bg-surface-container-high text-on-surface hover:bg-outline-variant/30 transition-all active:scale-95"
                          >
                            View Details
                          </button>
                          <button 
                            onClick={() => selectHotel(hotel)}
                            className={cn(
                              "px-6 py-4 rounded-xl transition-all active:scale-95 border-2",
                              selectedHotel?.id === hotel.id 
                                ? "bg-primary border-primary text-on-primary shadow-xl" 
                                : "bg-surface-container-lowest border-outline-variant/5 text-primary hover:border-primary"
                            )}
                          >
                            {selectedHotel?.id === hotel.id ? <Check className="w-5 h-5" /> : <TrendingDown className="w-5 h-5 rotate-180" />}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="col-span-12 py-32 text-center"
                  >
                     <div className="w-24 h-24 bg-primary/5 rounded-full flex items-center justify-center mx-auto mb-8 border border-primary/10">
                        <Filter className="w-10 h-10 text-primary/30" />
                     </div>
                     <h3 className="text-4xl font-black text-on-surface tracking-tighter mb-4">No Stays Found</h3>
                     <p className="text-on-surface-variant max-w-sm mx-auto font-medium opacity-60 italic mb-10 leading-relaxed">
                        Adjust your filters or sort order to discover refined alternatives in {destination?.name}.
                     </p>
                     <button 
                      onClick={() => setHotelFilters({ minStars: 0, maxPrice: MAX_HOTEL_USD, amenities: [] })}
                      className="text-primary font-black uppercase tracking-widest text-[10px] py-5 px-10 border-2 border-primary/20 rounded-full hover:bg-primary/5 transition-all shadow-xl hover:translate-y-[-2px] active:translate-y-0"
                     >
                      Clear Selection Filters
                     </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>
        </motion.div>
      )}
    </AnimatePresence>
  </div>

        {/* Sidebar Summary */}
        <aside className="lg:col-span-4">
          <div className="sticky top-28 space-y-6">
            <motion.div 
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-on-background text-on-primary p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden border border-white/5"
            >
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-primary/20 blur-[100px] rounded-full" />
              
              <h4 className="text-3xl font-black tracking-tighter mb-12 relative z-10">{t.itinerary.summary}</h4>
              
              <div className="space-y-10 relative z-10">
                <div className="group">
                  <p className="text-[9px] uppercase tracking-[0.3em] text-on-primary/40 font-black mb-3 group-hover:text-primary-container transition-colors">{t.itinerary.flights}</p>
                  <AnimatePresence mode="wait">
                    {selectedFlight ? (
                      <motion.div 
                        key={selectedFlight.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex justify-between items-start"
                      >
                        <div>
                          <p className="font-bold text-lg leading-tight">{selectedFlight.airline}</p>
                          <p className="text-[11px] text-on-primary/60 font-medium mt-1">{selectedFlight.depCode} → {selectedFlight.arrCode}</p>
                        </div>
                        <span className="font-black text-2xl tabular-nums animate-in fade-in slide-in-from-right-2">{formatPrice(selectedFlight.price * passengers)}</span>
                      </motion.div>
                    ) : (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 0.5 }}
                        className="flex flex-col items-center justify-center py-4 border-2 border-dashed border-white/10 rounded-2xl"
                      >
                         <p className="text-[10px] font-black uppercase tracking-widest mb-1">Select a Flight</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                
                <div className="group border-t border-on-primary/10 pt-8 min-h-[100px]">
                  <p className="text-[9px] uppercase tracking-[0.3em] text-on-primary/40 font-black mb-3 group-hover:text-primary-container transition-colors">{t.itinerary.hotels}</p>
                  <AnimatePresence mode="wait">
                    {selectedHotel ? (
                      <motion.div 
                        key={selectedHotel.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex justify-between items-start"
                      >
                        <div>
                          <p className="font-bold text-lg leading-tight">{selectedHotel.name}</p>
                          <p className="text-[11px] text-on-primary/60 font-medium mt-1">
                            {selectedRoom?.name || 'Sanctuary Stay'} ({stats.nights} {stats.nights === 1 ? 'night' : 'nights'})
                          </p>
                          {hotelOptions.breakfast && (
                            <p className="text-[10px] text-primary-container font-black mt-2 uppercase tracking-widest flex items-center gap-1">
                              <Check className="w-3 h-3" /> Breakfast Included
                            </p>
                          )}
                        </div>
                        <span className="font-black text-2xl tabular-nums animate-in fade-in slide-in-from-right-2">
                          {formatPrice(stats.hotelTotal + stats.optionsPrice)}
                        </span>
                      </motion.div>
                    ) : (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 0.5 }}
                        className="flex flex-col items-center justify-center py-4 border-2 border-dashed border-white/10 rounded-2xl"
                      >
                        <p className="text-[10px] font-black uppercase tracking-widest mb-1">Select a Stay</p>
                        <p className="text-[9px] font-medium text-on-primary/40">(Required to finalize)</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                
                <div className="pt-10 border-t border-on-primary/10">
                  <div className="flex justify-between items-baseline mb-4">
                    <span className="text-on-primary/50 font-black uppercase text-[10px] tracking-widest">{t.checkout.taxes}</span>
                    <span className="font-black text-lg tabular-nums opacity-80">{formatPrice(stats.taxes)}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-on-primary/40 font-black uppercase text-[10px] tracking-widest mb-1">{t.itinerary.total}</span>
                    <div className="flex justify-between items-end">
                      <p className="text-[3.5rem] font-black text-primary-container tracking-tighter leading-none tabular-nums animate-pulse-slow">{formatPrice(stats.total)}</p>
                      <p className="text-[9px] text-on-primary/40 font-bold mb-2 uppercase tracking-[0.1em]">All Included</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <button 
                onClick={handleComplete}
                disabled={isProcessing || !selectedHotel || !selectedFlight}
                className="w-full mt-12 bg-primary-container text-on-primary-container py-6 rounded-2xl font-black text-xl tracking-tight shadow-2xl hover:translate-y-[-4px] active:translate-y-[0px] transition-all disabled:opacity-30 disabled:translate-y-0 disabled:cursor-not-allowed flex items-center justify-center gap-3 group"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" /> {t.home.searching}
                  </>
                ) : (
                  <>
                    {t.itinerary.confirm}
                    <ArrowUpDown className="w-5 h-5 rotate-90 opacity-40 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </motion.div>

            <div className="bg-surface-container-low/50 backdrop-blur-md p-8 rounded-3xl border border-outline-variant/10 flex items-start gap-5 group transition-all hover:bg-surface-container-low">
              <Shield className="w-8 h-8 text-primary shrink-0 group-hover:scale-110 transition-transform" />
              <div>
                <p className="text-sm font-black mb-1 uppercase tracking-wider">Secure Custody</p>
                <p className="text-xs text-on-surface-variant font-medium leading-relaxed opacity-70">
                  Book now to lock in these curated prices. If rates drop within 24 hours, we'll refund the difference automatically.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Hotel Details Modal */}
      <AnimatePresence>
        {detailHotel && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
             <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => setDetailHotel(null)}
               className="absolute inset-0 bg-on-background/80 backdrop-blur-sm"
             />
             <motion.div 
               layoutId={`hotel-${detailHotel.id}`}
               className="relative bg-surface-container-lowest w-full max-w-5xl max-h-[90vh] rounded-[3rem] overflow-hidden flex flex-col md:flex-row shadow-2xl"
               initial={{ scale: 0.9, opacity: 0, y: 50 }}
               animate={{ scale: 1, opacity: 1, y: 0 }}
               exit={{ scale: 0.9, opacity: 0, y: 50 }}
             >
                <button 
                  onClick={() => setDetailHotel(null)}
                  className="absolute top-8 right-8 z-50 bg-white/20 backdrop-blur-xl p-3 rounded-full text-white hover:bg-primary transition-colors border border-white/20 shadow-xl"
                >
                  <X className="w-6 h-6" />
                </button>

                {/* Left: Gallery */}
                <div className="md:w-1/2 relative bg-on-background group">
                  <AnimatePresence mode="wait">
                    <motion.img 
                      key={activeImageIdx}
                      src={detailHotel.images[activeImageIdx]}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </AnimatePresence>
                  
                  {detailHotel.images.length > 1 && (
                    <>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setActiveImageIdx(prev => (prev === 0 ? detailHotel.images.length - 1 : prev - 1)); }}
                        className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-md p-4 rounded-full text-white hover:bg-primary/80 transition-all border border-white/10 opacity-0 group-hover:opacity-100"
                      >
                        <ChevronLeft className="w-6 h-6" />
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setActiveImageIdx(prev => (prev === detailHotel.images.length - 1 ? 0 : prev + 1)); }}
                        className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-md p-4 rounded-full text-white hover:bg-primary/80 transition-all border border-white/10 opacity-0 group-hover:opacity-100"
                      >
                        <ChevronRight className="w-6 h-6" />
                      </button>
                      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-2">
                        {detailHotel.images.map((_, i) => (
                          <div key={i} className={cn("w-2 h-2 rounded-full transition-all", i === activeImageIdx ? "bg-primary w-8" : "bg-white/40")} />
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* Right: Info & Config */}
                <div className="md:w-1/2 p-12 overflow-y-auto bg-surface-container-lowest">
                   <div className="flex items-center gap-3 mb-6">
                      <div className="flex gap-0.5">
                        {Array.from({ length: detailHotel.stars }).map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 text-primary fill-current" />
                        ))}
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant opacity-40">Verified sanctuary</span>
                   </div>
                   
                   <h2 className="text-5xl font-black text-on-surface tracking-tighter mb-4 leading-tight">{detailHotel.name}</h2>
                   <div className="flex items-center gap-6 mb-10 text-on-surface-variant font-black uppercase tracking-widest text-[10px]">
                      <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> {detailHotel.location}</span>
                      <span className="flex items-center gap-2 bg-on-background/5 px-3 py-1 rounded">{detailHotel.rating} Guest Score</span>
                   </div>

                   <p className="text-on-surface-variant text-lg leading-relaxed font-medium mb-12 opacity-80">
                      {detailHotel.desc}
                   </p>

                   {/* Room Selection Details */}
                   <div className="mb-12">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-on-surface-variant/40 mb-6 flex items-center gap-3">
                        Capacity Configuration <div className="h-[1px] flex-1 bg-outline-variant/10" />
                      </h4>
                      <div className="flex items-center gap-6 p-6 bg-surface-container-low rounded-2xl border border-outline-variant/10">
                        <Users className="w-6 h-6 text-primary" />
                        <div className="flex-1">
                          <p className="text-sm font-black text-on-surface">Number of Rooms</p>
                          <p className="text-[10px] text-on-surface-variant font-medium opacity-60">Total price updates dynamically</p>
                        </div>
                        <div className="flex items-center gap-4 bg-white/50 p-1.5 rounded-xl border border-outline-variant/10">
                          <button 
                            onClick={() => setRoomCount(Math.max(1, roomCount - 1))}
                            className="w-10 h-10 rounded-lg bg-surface-container-high flex items-center justify-center font-black hover:bg-primary/10 transition-colors"
                          >
                            -
                          </button>
                          <span className="w-8 text-center font-black text-lg">{roomCount}</span>
                          <button 
                            onClick={() => setRoomCount(Math.min(5, roomCount + 1))}
                            className="w-10 h-10 rounded-lg bg-surface-container-high flex items-center justify-center font-black hover:bg-primary/10 transition-colors"
                          >
                            +
                          </button>
                        </div>
                      </div>
                   </div>

                   {/* Room Types */}
                   <div className="mb-12">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-on-surface-variant/40 mb-6 flex items-center gap-3">
                        Select Your Sanctuary <div className="h-[1px] flex-1 bg-outline-variant/10" />
                      </h4>
                      <div className="space-y-4">
                        {(detailHotel.roomTypes || [{ id: 'std', name: 'Standard Room', priceMultiplier: 1, description: 'Comfortable living with essential luxuries.' }]).map((room) => {
                          const isSelected = selectedHotel?.id === detailHotel.id && selectedRoom?.id === room.id;
                          return (
                            <button 
                              key={room.id}
                              onClick={() => setSelectedRoom(room)}
                              className={cn(
                                "w-full text-left p-6 rounded-2xl border transition-all relative overflow-hidden group/room",
                                isSelected 
                                  ? "bg-primary/5 border-primary shadow-inner" 
                                  : "bg-surface-container-low border-outline-variant/10 hover:border-primary/40"
                              )}
                            >
                              <div className="flex justify-between items-start relative z-10">
                                <div className="flex gap-6">
                                  {room.images?.[0] && (
                                    <img 
                                      src={room.images[0]} 
                                      className="w-20 h-20 rounded-xl object-cover shadow-lg border border-white/20" 
                                      referrerPolicy="no-referrer"
                                    />
                                  )}
                                  <div>
                                    <p className="font-black text-on-surface text-lg mb-1">{room.name}</p>
                                    <p className="text-xs text-on-surface-variant font-medium opacity-60 leading-relaxed">{room.description}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="text-xl font-black text-primary tabular-nums">{formatPrice(Math.round(detailHotel.price * room.priceMultiplier))}</p>
                                  <p className="text-[8px] font-black uppercase tracking-widest opacity-40">Per Night / Room</p>
                                </div>
                              </div>
                              {isSelected && <div className="absolute top-4 right-4 text-primary"><Check className="w-5 h-5" /></div>}
                            </button>
                          );
                        })}
                      </div>
                   </div>

                   {/* Options & Selection */}
                   <div className="space-y-4 pt-4">
                      <button 
                        onClick={() => setHotelOptions({ ...hotelOptions, breakfast: !hotelOptions.breakfast })}
                        className={cn(
                          "w-full p-5 rounded-2xl border flex justify-between items-center transition-all",
                          hotelOptions.breakfast 
                            ? "bg-tertiary-container/10 border-tertiary/40 text-tertiary" 
                            : "bg-surface-container-low border-outline-variant/10 text-on-surface-variant"
                        )}
                      >
                        <div className="flex items-center gap-4">
                          <Coffee className="w-5 h-5" />
                          <span className="text-xs font-black uppercase tracking-widest">Gourmet Breakfast Protocol</span>
                        </div>
                        <span className="font-black text-sm">+{formatPrice(45)}/nt</span>
                      </button>

                      <div className="bg-surface-container-high/50 p-6 rounded-3xl border border-outline-variant/5 mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/60">Duration</span>
                          <span className="text-sm font-black text-on-surface">{stats.nights} Nights</span>
                        </div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/60">Rooms</span>
                          <span className="text-sm font-black text-on-surface">x{roomCount}</span>
                        </div>
                        <div className="h-[1px] bg-outline-variant/10 my-4" />
                        <div className="flex justify-between items-end">
                           <span className="text-[10px] font-black uppercase tracking-widest text-primary">Est. Stay Total</span>
                           <span className="text-3xl font-black text-on-surface tracking-tighter tabular-nums">
                             {formatPrice((detailHotel.price * (selectedRoom?.priceMultiplier || 1) * stats.nights * roomCount) + (hotelOptions.breakfast ? 45 * stats.nights * roomCount : 0))}
                           </span>
                        </div>
                      </div>

                      <button 
                        onClick={() => selectHotel(detailHotel, selectedRoom || undefined)}
                        className="w-full py-7 bg-primary text-on-primary rounded-3xl font-black text-xl tracking-tight shadow-xl hover:translate-y-[-4px] active:translate-y-0 transition-all flex items-center justify-center gap-3 mt-4"
                      >
                        {selectedHotel?.id === detailHotel.id ? 'Stay Selected' : 'Confirm Choice'}
                        <Shield className="w-6 h-6 opacity-40" />
                      </button>
                   </div>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </main>
  );
}
