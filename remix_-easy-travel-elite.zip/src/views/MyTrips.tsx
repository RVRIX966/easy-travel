import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Plane, Hotel, MapPin, Calendar, Clock, CreditCard, CheckCircle2, ArrowRight, Briefcase } from 'lucide-react';
import { useAuth, useCurrency } from '../App';
import { StoredTrip } from '../types';
import { cn } from '@/src/lib/utils';

export default function MyTrips() {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const [trips, setTrips] = useState<StoredTrip[]>([]);

  useEffect(() => {
    if (user) {
      const allTrips: StoredTrip[] = JSON.parse(localStorage.getItem('et_trips') || '[]');
      const userTrips = allTrips.filter(t => t.userId === user.id);
      setTrips(userTrips.sort((a, b) => new Date(b.bookedAt).getTime() - new Date(a.bookedAt).getTime()));
    }
  }, [user]);

  if (!user) {
    return (
      <main className="min-h-screen pt-40 pb-20 px-8 flex flex-col items-center justify-center bg-surface-container-lowest">
        <h2 className="text-4xl font-black tracking-tighter mb-4">Access Denied</h2>
        <p className="text-on-surface-variant font-medium opacity-60">Please sign in to view your trips.</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen pt-40 pb-20 px-8 bg-surface-container-low">
      <div className="max-w-7xl mx-auto">
        <header className="mb-16">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 text-primary mb-4">
            <Briefcase className="w-5 h-5" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em]">Personal Itinerary</span>
          </motion.div>
          <h1 className="text-6xl font-black text-on-surface tracking-tighter leading-none mb-6">My Trips</h1>
          <p className="text-xl text-on-surface-variant font-medium opacity-60">
            Welcome back, {user.firstName}. You have {trips.length} curated {trips.length === 1 ? 'adventure' : 'adventures'} booked.
          </p>
        </header>

        {trips.length === 0 ? (
          <div className="bg-white rounded-[3rem] p-20 text-center border border-outline-variant/10 shadow-2xl">
            <div className="w-20 h-20 bg-surface-container-low rounded-full flex items-center justify-center mx-auto mb-8">
              <MapPin className="w-8 h-8 text-on-surface-variant opacity-20" />
            </div>
            <h3 className="text-2xl font-black tracking-tighter mb-4">No trips found</h3>
            <p className="text-on-surface-variant font-medium opacity-60 mb-10">Your future legends will appear here once booked.</p>
            <button className="px-10 py-5 bg-on-background text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-primary transition-all">
              Discover Destinations
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-10">
            {trips.map((trip) => (
              <motion.div 
                key={trip.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-[3rem] overflow-hidden border border-outline-variant/5 shadow-xl hover:shadow-2xl transition-all group"
              >
                <div className="flex flex-col lg:flex-row">
                  {/* Visual Header */}
                  <div className="lg:w-1/3 relative h-64 lg:h-auto overflow-hidden">
                    <img 
                      src={trip.hotel?.images?.[0] || 'https://picsum.photos/seed/resort/800/600'} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-8 left-8">
                       <div className="flex items-center gap-2 mb-2">
                         <span className="px-3 py-1 bg-primary text-[8px] font-black uppercase tracking-widest text-on-primary rounded-full">
                           {trip.status}
                         </span>
                       </div>
                       <h3 className="text-3xl font-black text-white tracking-tighter">{trip.hotel?.location.split(',')[0]}</h3>
                    </div>
                  </div>

                  {/* Trip Details */}
                  <div className="flex-1 p-12 lg:p-16">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
                      <div className="space-y-6">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                             <Plane className="w-6 h-6 text-primary" />
                           </div>
                           <div>
                             <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40">Flight Sequence</p>
                             <p className="font-black text-on-surface">{trip.flight?.airline} • {trip.flight?.code}</p>
                           </div>
                        </div>
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                             <Hotel className="w-6 h-6 text-primary" />
                           </div>
                           <div>
                             <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40">Sanctuary Details</p>
                             <p className="font-black text-on-surface">{trip.hotel?.name}</p>
                             <p className="text-xs text-on-surface-variant font-medium opacity-60">{trip.room?.name} • {trip.nights} Nights</p>
                           </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                             <Calendar className="w-6 h-6 text-primary" />
                           </div>
                           <div>
                             <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40">Timeline</p>
                             <p className="font-black text-on-surface">{new Date(trip.checkInDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} — {new Date(trip.checkOutDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                           </div>
                        </div>
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                             <CreditCard className="w-6 h-6 text-primary" />
                           </div>
                           <div>
                             <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40">Financial Record</p>
                             <p className="font-black text-on-surface">{formatPrice(trip.totalPrice)} (Incl. Taxes)</p>
                           </div>
                        </div>
                      </div>
                    </div>

                    <div className="pt-10 border-t border-outline-variant/10 flex flex-col sm:flex-row justify-between items-center gap-6">
                       <div className="flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5 text-primary" />
                          <p className="text-xs font-black uppercase tracking-widest text-on-surface-variant/60">Booking ID: <span className="text-on-surface">{trip.id}</span></p>
                       </div>
                       <div className="flex gap-4">
                         <button className="px-8 py-4 rounded-xl border border-outline-variant/10 text-[10px] font-black uppercase tracking-widest hover:bg-surface-container-low transition-all">Support</button>
                         <button className="px-8 py-4 rounded-xl bg-on-background text-white text-[10px] font-black uppercase tracking-widest hover:bg-primary transition-all flex items-center gap-2">
                           Manifest
                           <ArrowRight className="w-4 h-4" />
                         </button>
                       </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
