import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Phone, Mail, ChevronDown, Send, Loader2, CheckCircle2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useLanguage } from '../App';

export default function Support() {
  const { t } = useLanguage();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSending, setIsSending] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setIsSent(true);
      setFormState({ name: '', email: '', message: '' });
    }, 1500);
  };

  return (
    <main className="pt-24 pb-32 max-w-7xl mx-auto px-8 min-h-screen">
      <section className="mb-20">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-6xl font-black tracking-tighter leading-none text-on-surface mb-8"
        >
          {t.support.title}
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-xl text-on-surface-variant max-w-xl leading-relaxed font-medium"
        >
          {t.support.desc}
        </motion.p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Contact Form */}
        <div className="lg:col-span-7">
          <div className="bg-surface-container-low p-10 rounded-[2.5rem] ambient-shadow border border-outline-variant/10 shadow-xl">
            <h3 className="text-2xl font-black tracking-tight text-on-surface mb-8">{t.support.formTitle}</h3>
            
            {isSent ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-20 text-center"
              >
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 text-primary">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-2xl font-bold mb-2">{t.support.sentHead}</h4>
                <p className="text-on-surface-variant mb-8">{t.support.sentSub}</p>
                <button 
                  onClick={() => setIsSent(false)}
                  className="text-primary font-bold underline underline-offset-4"
                >
                  {t.support.sendAnother}
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="col-span-2 md:col-span-1">
                    <label className="text-[10px] uppercase font-black tracking-[0.2em] text-on-surface-variant mb-3 block">{t.support.nameLabel}</label>
                    <input 
                      required
                      value={formState.name}
                      onChange={(e) => setFormState({...formState, name: e.target.value})}
                      className="w-full bg-surface-container-lowest border border-outline-variant/10 rounded-2xl px-6 py-4.5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30" 
                      placeholder="John Doe" 
                    />
                  </div>
                  <div className="col-span-2 md:col-span-1">
                    <label className="text-[10px] uppercase font-black tracking-[0.2em] text-on-surface-variant mb-3 block">{t.support.emailLabel}</label>
                    <input 
                      required
                      type="email"
                      value={formState.email}
                      onChange={(e) => setFormState({...formState, email: e.target.value})}
                      className="w-full bg-surface-container-lowest border border-outline-variant/10 rounded-2xl px-6 py-4.5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30" 
                      placeholder="john@example.com" 
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase font-black tracking-[0.2em] text-on-surface-variant mb-3 block">{t.support.messageLabel}</label>
                  <textarea 
                    required
                    value={formState.message}
                    onChange={(e) => setFormState({...formState, message: e.target.value})}
                    rows={6}
                    className="w-full bg-surface-container-lowest border border-outline-variant/10 rounded-2xl px-6 py-4.5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold resize-none placeholder:opacity-30" 
                    placeholder="Tell us about your next adventure..." 
                  />
                </div>
                <button 
                  disabled={isSending}
                  className="bg-primary text-on-primary w-full py-5 rounded-2xl font-black uppercase tracking-[0.3em] text-xs shadow-xl flex items-center justify-center gap-4 active:scale-95 transition-all disabled:opacity-50"
                >
                  {isSending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> {t.support.transmitting}
                    </>
                  ) : (
                    <>
                      {t.support.sendBtn} <Send className="w-5 h-5" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Info & FAQ */}
        <div className="lg:col-span-5 space-y-12">
          {/* Direct channels */}
          <div className="grid grid-cols-1 gap-4">
            <div className="flex items-center gap-6 p-8 bg-surface-container-low rounded-[2rem] border border-outline-variant/5 shadow-md group transition-all hover:bg-surface-container-low/80 cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-secondary-container/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform shadow-sm">
                <MessageSquare className="w-7 h-7" />
              </div>
              <div>
                <p className="font-black text-xl text-on-surface tracking-tight">{t.support.chat}</p>
                <p className="text-sm font-medium text-on-surface-variant opacity-60">{t.support.chatSub}</p>
              </div>
            </div>
            <div className="flex items-center gap-6 p-8 bg-surface-container-low rounded-[2rem] border border-outline-variant/5 shadow-md group transition-all hover:bg-surface-container-low/80 cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-secondary-container/30 flex items-center justify-center text-primary group-hover:scale-110 transition-transform shadow-sm">
                <Phone className="w-7 h-7" />
              </div>
              <div>
                <p className="font-black text-xl text-on-surface tracking-tight">{t.support.phone}</p>
                <p className="text-sm font-medium text-on-surface-variant opacity-60">{t.support.phoneSub}</p>
              </div>
            </div>
          </div>

          {/* FAQ */}
          <div className="space-y-8 mt-10">
            <h4 className="text-2xl font-black tracking-tighter text-on-surface">{t.support.faqTitle}</h4>
            <div className="space-y-4">
              {[
                { q: "How do you curate the 'Easy Travel' destinations?", a: "Our proprietary algorithm analyzes over 150 data points per location, focusing on safety, quietness, architectural significance, and current seasonal performance to ensure your peace of mind." },
                { q: "Can I customize the generated itineraries?", a: "Absolutely. Once an itinerary is generated, you can swap flights, hotels, and activities. The concierge service also allows for fully bespoke adjusments via direct messaging." },
                { q: "What is the 'Price Protection Policy'?", a: "We monitor prices for 24 hours after booking. If the rate for the exact same package drops, we automatically credit the difference back to your original payment method." },
                { q: "Do you handle visa applications?", a: "We provide comprehensive documentation and step-by-step guides for all electronic visas. For standard diplomatic visas, we provide pre-filled forms to expedite your appointment." }
              ].map((faq, i) => (
                <div key={i} className="bg-surface-container-lowest rounded-2xl border border-outline-variant/10 overflow-hidden shadow-sm transition-all hover:shadow-md">
                  <button 
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-6 text-left transition-colors hover:bg-surface-container-high/20"
                  >
                    <span className="font-black text-on-surface pr-6 tracking-tight">{faq.q}</span>
                    <ChevronDown className={cn("w-5 h-5 transition-transform shrink-0 opacity-40", openFaq === i ? "rotate-180 opacity-100 text-primary" : "")} />
                  </button>
                  <AnimatePresence>
                    {openFaq === i && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="p-8 pt-0 text-on-surface-variant font-medium text-base leading-relaxed opacity-70"
                      >
                        {faq.a}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
