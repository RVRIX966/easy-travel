import React, { useState, useEffect, useMemo } from 'react';
import { FileText, ArrowRight, ShieldCheck, Loader2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useCurrency } from '../App';
import { SearchFilters, Destination } from '../types';
import { searchDestinations } from '../services/geminiService';
import { FALLBACK_FLIGHTS, FALLBACK_HOTELS } from '../constants';

interface DestinationsProps {
  initialFilters: SearchFilters | null;
  onSelect: (destination: Destination) => void;
}

const DESTINATIONS: Destination[] = [
  {
    id: 1,
    name: 'Jaipur, India',
    image: 'https://picsum.photos/seed/jaipur/1200/800',
    type: 'Cultural Luxury',
    price: 2140,
    visa: { type: 'e-Visa', cost: 25, time: '72 Hours' },
    isFeatured: true,
    tags: ['Cultural High']
  },
  {
    id: 99,
    name: 'Bali, Indonesia',
    image: 'https://picsum.photos/seed/bali-surf/1200/800',
    type: 'Island Paradise',
    price: 1650,
    visa: { type: 'On Arrival', cost: 35, time: 'Instant' },
    tags: ['Quiet Solitude', 'Beach']
  },
  {
    id: 100,
    name: 'Phuket, Thailand',
    image: 'https://picsum.photos/seed/phuket/1200/800',
    type: 'Tropical Luxury',
    price: 2800,
    visa: { type: 'Exempt', cost: 0, time: 'Instant' },
    tags: ['Luxury', 'Beach']
  },
  {
    id: 2,
    name: 'Ubud, Bali, Indonesia',
    image: 'https://picsum.photos/seed/ubud/1200/800',
    type: 'Eco-Retreat',
    price: 1850,
    visa: { type: 'On Arrival', cost: 35, time: 'Instant' },
    tags: ['Quiet Solitude']
  },
  {
    id: 5,
    name: 'Siem Reap, Cambodia',
    image: 'https://picsum.photos/seed/siemreap/800/600',
    type: 'Historical Gem',
    price: 940,
    visa: { type: 'e-Visa', cost: 30, time: '24 Hours' },
    tags: ['Cultural High', 'Quiet Solitude']
  },
  {
    id: 6,
    name: 'Chiang Mai, Thailand',
    image: 'https://picsum.photos/seed/chiangmai/800/600',
    type: 'Cultural Hub',
    price: 780,
    visa: { type: 'Exempt', cost: 0, time: 'Instant' },
    tags: ['Cultural High', 'Quiet Solitude']
  },
  {
    id: 3,
    name: 'London, UK',
    image: 'https://picsum.photos/seed/london/800/600',
    type: 'Metropolitan',
    price: 3200,
    desc: 'A refined metropolitan experience during the crisp autumn season.',
    visa: { type: 'Standard', cost: 115, time: '3 Weeks' },
    tags: ['Cultural High']
  },
  {
    id: 4,
    name: 'Chefchaouen, Morocco',
    image: 'https://picsum.photos/seed/morocco/1200/800',
    type: 'Seasonal Pick',
    price: 1280,
    visa: { type: 'Standard', cost: 50, time: '1 Week' },
    tags: ['Quiet Solitude', 'Cultural High']
  },
  {
    id: 10,
    name: 'Sharm El Sheikh, Egypt',
    image: 'https://picsum.photos/seed/sharm/1200/800',
    type: 'Luxury Beach',
    price: 1550,
    visa: { type: 'On Arrival', cost: 25, time: 'Instant' },
    tags: ['Beach', 'Luxury']
  }
];

export default function Destinations({ initialFilters, onSelect }: DestinationsProps) {
  const { t } = useLanguage();
  const { formatPrice } = useCurrency();
  const [maxBudget, setMaxBudget] = useState(initialFilters?.budget || 3500);
  const [season, setSeason] = useState('Spring Renewal');
  const [selectedMode, setSelectedMode] = useState<string | null>(
    initialFilters?.preferences[0] || 'Cultural High'
  );
  const [isFiltering, setIsFiltering] = useState(false);
  const [destinations, setDestinations] = useState<Destination[]>(DESTINATIONS);
  const [error, setError] = useState<string | null>(null);

  // Trigger AI search on mount if filters provided
  useEffect(() => {
    if (initialFilters) {
      const performAISearch = async () => {
        setIsFiltering(true);
        setError(null);
        try {
          const results = await searchDestinations(initialFilters);
          if (results && results.length > 0) {
            setDestinations(results);
          }
        } catch (err) {
          console.error("AI Search Failed:", err);
          setError("We couldn't reach the celestial navigation system. Using cached data.");
        } finally {
          setIsFiltering(false);
        }
      };
      performAISearch();
    }
  }, [initialFilters]);

  // Filter logic with Smart Fallback
  const { displayResults, isFallback } = useMemo(() => {
    let results = destinations.filter(item => {
      const budgetMatch = item.price <= maxBudget;
      const modeMatch = selectedMode ? item.tags.includes(selectedMode) : true;
      return budgetMatch && modeMatch;
    });

    if (results.length > 0) {
      return { displayResults: results, isFallback: false };
    }

    // Fallback: If no matches within budget, show cheapest options or nearby matches
    // We sort all available destinations by price and show the top 3-5
    const fallbackResults = [...destinations].sort((a, b) => a.price - b.price).slice(0, 4);
    return { displayResults: fallbackResults, isFallback: true };
  }, [maxBudget, selectedMode, destinations]);

  // Simulate loading on filter change
  useEffect(() => {
    // Only simulate if not already fetching from AI
    if (!initialFilters || destinations.length > 0) {
      setIsFiltering(true);
      const timer = setTimeout(() => setIsFiltering(false), 500);
      return () => clearTimeout(timer);
    }
  }, [maxBudget, selectedMode, season]);

  return (
    <main className="pt-24 pb-32 max-w-7xl mx-auto px-8 min-h-screen">
      <section className="mb-16">
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-[3.5rem] font-black tracking-tighter leading-[1.1] text-on-surface mb-6"
        >
          {t.destinations.title}
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-lg text-on-surface-variant max-w-xl leading-relaxed font-medium"
        >
          {t.destinations.desc}
        </motion.p>
      </section>

      {/* Search & Filter Bar */}
      <div className="bg-surface-container-low rounded-2xl p-8 mb-16 ambient-shadow-lg flex flex-col lg:flex-row gap-8 items-start border border-outline-variant/10">
        <div className="flex-1 w-full lg:w-auto min-w-[280px]">
          <label className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6 block">{t.destinations.maxBudget}</label>
          <div className="space-y-6">
            <input 
              className="w-full h-2 bg-surface-container-low rounded-lg appearance-none cursor-pointer accent-primary block" 
              type="range" 
              value={maxBudget} 
              onChange={(e) => setMaxBudget(Number(e.target.value))}
              max="10000" 
              min="500" 
              step="100"
            />
            <div className="flex flex-col gap-1.5">
              <span className="text-primary font-black text-3xl tracking-tighter tabular-nums leading-none">{formatPrice(maxBudget)}</span>
              <p className="text-[10px] text-on-surface-variant/40 font-black uppercase tracking-[0.1em]">
                Maximum limit: {formatPrice(10000)}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex-1 w-full lg:w-auto min-w-[200px]">
          <label className="block text-[0.65rem] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6">{t.destinations.season}</label>
          <div className="relative group">
            <select 
              value={season}
              onChange={(e) => setSeason(e.target.value)}
              className="w-full bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/5 outline-none focus:ring-4 focus:ring-primary/10 text-on-surface font-black cursor-pointer appearance-none transition-all hover:border-outline-variant/30 px-8"
            >
              <option>Spring Renewal</option>
              <option>Summer Solstice</option>
              <option>Autumn Equinox</option>
              <option>Winter Silence</option>
            </select>
            <Sparkles className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-outline-variant w-5 h-5 group-hover:text-primary transition-colors" />
          </div>
        </div>

        <div className="w-full lg:w-auto">
          <label className="block text-[0.65rem] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 mb-6">Travel Mode</label>
          <div className="flex flex-wrap items-center gap-4">
            {['Cultural High', 'Quiet Solitude'].map((mode) => (
              <button 
                key={mode}
                onClick={() => setSelectedMode(selectedMode === mode ? null : mode)}
                className={cn(
                  "px-8 py-6 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all transform active:scale-95 whitespace-nowrap shadow-xl border",
                  selectedMode === mode 
                    ? "bg-primary text-on-primary border-primary shadow-primary/20" 
                    : "bg-surface-container-lowest text-on-surface-variant border-outline-variant/5 hover:bg-surface-container-highest hover:border-outline-variant/30"
                )}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Smart Fallback Header */}
      {isFallback && !isFiltering && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 p-8 rounded-[2rem] bg-surface-container-high border border-primary/20 flex flex-col md:flex-row md:items-center justify-between gap-8 shadow-2xl"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-3 text-primary">
               <Sparkles className="w-6 h-6" />
               <h3 className="text-xl font-black tracking-tight">Expanding search parameters...</h3>
            </div>
            <p className="text-sm font-medium text-on-surface-variant opacity-70">No destinations met all exact constraints. Here are the closest refinements and high-value alternatives for your {formatPrice(maxBudget)} budget.</p>
</div>
<button 
  onClick={() => setMaxBudget(prev => prev + 500)}
  className="px-10 py-5 rounded-2xl bg-primary text-on-primary font-black text-xs uppercase tracking-widest shadow-xl hover:translate-y-[-2px] transition-all active:translate-y-0"
>
  Increase Budget by {formatPrice(500)}
</button>
        </motion.div>
      )}

      {/* Results Grid */}
      <div className="relative min-h-[500px]">
        <AnimatePresence mode="popLayout">
          {isFiltering ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-background/60 backdrop-blur-[4px] rounded-3xl"
            >
              <div className="relative">
                <Loader2 className="w-16 h-16 text-primary animate-spin" />
                <div className="absolute inset-0 bg-primary/10 rounded-full animate-ping opacity-20" />
              </div>
              <p className="text-on-surface-variant font-black uppercase tracking-[0.3em] text-[10px] mt-8">
                {t.destinations.loading}
              </p>
            </motion.div>
          ) : null}
        </AnimatePresence>

        {error && (
          <div className="bg-tertiary-container/10 border border-tertiary/20 p-6 rounded-2xl mb-12 flex items-center gap-4 text-tertiary">
            <Sparkles className="w-5 h-5" />
            <p className="text-xs font-black uppercase tracking-widest">{error}</p>
          </div>
        )}

        <div className={cn(
          "grid grid-cols-1 md:grid-cols-12 gap-10 transition-all duration-500",
          isFiltering && "opacity-10 scale-[0.98] pointer-events-none grayscale"
        )}>
          {displayResults.length === 0 ? (
            <div className="col-span-12 py-40 text-center text-on-surface-variant">
              <p className="text-3xl font-black tracking-tighter mb-4">{t.destinations.noResults}</p>
              <button 
                onClick={() => { setMaxBudget(10000); setSelectedMode(null); }}
                className="text-primary font-black uppercase tracking-widest text-xs hover:tracking-[0.2em] transition-all"
              >
                {t.destinations.resetFilters}
              </button>
            </div>
          ) : (
            displayResults.map((item, idx) => {
              if (item.isFeatured && idx === 0) {
                return (
                  <motion.div 
                    layout
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="md:col-span-12 lg:col-span-8 bg-surface-container-low rounded-[2.5rem] overflow-hidden group cursor-pointer ambient-shadow-lg border border-outline-variant/5 flex flex-col lg:flex-row transition-all hover:shadow-[0_45px_100px_-30px_rgba(0,0,0,0.2)] active:scale-[0.99]"
                    onClick={() => onSelect(item)}
                  >
                    <div className="lg:w-3/5 h-96 lg:h-auto relative overflow-hidden">
                      <img 
                        className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                        src={item.image} 
                        alt={item.name}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-8 left-8 bg-surface-container-lowest/90 backdrop-blur-xl px-6 py-3 rounded-full text-[10px] font-black tracking-[0.2em] uppercase text-primary border border-white/20 shadow-xl">
                        {item.type}
                      </div>
                    </div>
                    <div className="lg:w-2/5 p-12 flex flex-col justify-between">
                      <div>
                        <h2 className="text-4xl font-black text-on-surface mb-4 tracking-tighter">{item.name}</h2>
                        <div className="text-[3.5rem] font-black text-primary tracking-tighter mb-10 tabular-nums leading-none">
                          {formatPrice(item.price)} <span className="text-xs font-black text-on-surface-variant tracking-[0.2em] uppercase opacity-40 block mt-2">Inclusive Total</span>
                        </div>
                        <div className="space-y-6 mb-12 border-t border-outline-variant/10 pt-10">
                          <div className="flex justify-between items-center text-sm font-medium">
                            <span className="text-on-surface-variant opacity-70">Round Trip Aero</span>
                            <span className="font-black text-on-surface">{formatPrice(Math.round(item.price * 0.4))}</span>
                          </div>
                          <div className="flex justify-between items-center text-sm font-medium">
                            <span className="text-on-surface-variant opacity-70">Boutique Sanctuary</span>
                            <span className="font-black text-on-surface">{formatPrice(Math.round(item.price * 0.4))}</span>
                          </div>
                          <div className="flex justify-between items-center text-sm font-medium">
                            <span className="text-on-surface-variant opacity-70">Daily Reconnaissance</span>
                            <span className="font-black text-on-surface">{formatPrice(Math.round(item.price * 0.2))}</span>
                          </div>
                        </div>
                      </div>
                      <div className="p-6 bg-surface-container-high/40 rounded-2xl border border-outline-variant/10 ring-1 ring-white/5">
                        <div className="flex items-center gap-3 mb-4 text-primary">
                          <FileText className="w-5 h-5" />
                          <span className="text-[10px] font-black uppercase tracking-[0.3em]">{item.visa.type} Protocol</span>
                        </div>
                        <div className="grid grid-cols-2 gap-y-3 text-[11px] font-black">
                          <span className="text-on-surface-variant opacity-50 uppercase tracking-widest">Processing:</span> 
                          <span className="text-on-surface text-right">{item.visa.time}</span>
                          <span className="text-on-surface-variant opacity-50 uppercase tracking-widest">Protocol Cost:</span> 
                          <span className="text-on-surface text-right">{formatPrice(item.visa.cost)}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              }
              return (
                <motion.div 
                  layout
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.05 * idx }}
                  className="md:col-span-6 lg:col-span-4 bg-surface-container-low rounded-[2.5rem] overflow-hidden group flex flex-col cursor-pointer ambient-shadow border border-outline-variant/5 hover:shadow-2xl transition-all active:scale-[0.98]"
                  onClick={onSelect}
                >
                  <div className="h-72 relative overflow-hidden" onClick={() => onSelect(item)}>
                    <img 
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                      src={item.image} 
                      alt={item.name}
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-6 right-6 bg-black/60 backdrop-blur-xl px-4 py-2 rounded-xl text-[9px] font-black text-white uppercase tracking-[0.2em]">
                      {item.type}
                    </div>
                  </div>
                  <div className="p-10 flex-1 flex flex-col justify-between" onClick={() => onSelect(item)}>
                    <div>
                      <h3 className="text-3xl font-black text-on-surface mb-3 tracking-tighter">{item.name}</h3>
                      <div className="text-4xl font-black text-primary tracking-tighter mb-8 tabular-nums">{formatPrice(item.price)}</div>
                      {item.desc ? (
                        <p className="text-sm text-on-surface-variant font-medium leading-relaxed mb-8 opacity-60">{item.desc}</p>
                      ) : (
                        <div className="flex gap-5 text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant/50 border-t border-outline-variant/10 pt-8 mb-8">
                          <span>{formatPrice(Math.round(item.price / 10))}/Day Avg</span>
                          <span className="opacity-20">•</span>
                          <span>Luxury Stay</span>
                        </div>
                      )}
                    </div>
                    <div className="p-5 bg-surface-container-high/40 rounded-2xl border border-outline-variant/10 flex items-center justify-between ring-1 ring-white/5">
                      <div className="flex items-center gap-3 text-primary">
                        <ShieldCheck className="w-5 h-5" />
                        <span className="text-[10px] font-black uppercase tracking-[0.3em]">IMMIGRATION</span>
                      </div>
                      <p className="text-[11px] text-on-surface font-black uppercase tracking-widest">{item.visa.type} • {formatPrice(item.visa.cost)}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>
    </main>
  );
}

