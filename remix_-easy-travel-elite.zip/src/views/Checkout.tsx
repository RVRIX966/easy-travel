import React, { useState, useEffect } from 'react';
import { CreditCard, Wallet, Landmark, Calendar, Lock, ArrowRight, CheckCircle2, Loader2, Sparkles, Globe, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { useLanguage, useCurrency, useAuth } from '../App';
import { BookingSummary, StoredTrip } from '../types';

export default function Checkout({ booking, onConfirm }: { booking: BookingSummary | null, onConfirm: () => void }) {
  const { t } = useLanguage();
  const { formatPrice } = useCurrency();
  const { user } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardInfo, setCardInfo] = useState({ number: '', expiry: '', cvv: '', name: '' });
  const [paymentMode, setPaymentMode] = useState<'full' | 'installments'>('full');
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState(false);
  const [promoError, setPromoError] = useState('');
  const [installmentPlan, setInstallmentPlan] = useState(6);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showPromoPopup, setShowPromoPopup] = useState(false);

  useEffect(() => {
    // Reset scroll position to top
    window.scrollTo(0, 0);

    // Show promo popup after 1 second
    const timer = setTimeout(() => setShowPromoPopup(true), 1000);
    
    // Auto-dismiss after 60 seconds
    const dismissTimer = setTimeout(() => setShowPromoPopup(false), 61000);
    
    return () => {
      clearTimeout(timer);
      clearTimeout(dismissTimer);
    };
  }, []);

  const subtotal = booking ? (booking.totalPrice - booking.taxes) : 4228;
  const taxesAmount = booking ? booking.taxes : (subtotal * 0.05);
  const fullTotal = subtotal + taxesAmount;
  
  const discountAmount = fullTotal * (appliedPromo ? 0.15 : 0);
  const finalTotal = fullTotal - discountAmount;

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').substring(0, 16);
    val = val.replace(/(\d{4})/g, '$1 ').trim();
    setCardInfo({ ...cardInfo, number: val });
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').substring(0, 4);
    if (val.length > 2) val = val.substring(0, 2) + '/' + val.substring(2);
    setCardInfo({ ...cardInfo, expiry: val });
  };

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      // Save Trip to localStorage
      if (booking && user) {
        const newTrip: StoredTrip = {
          ...booking,
          id: `ET-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
          userId: user.id,
          bookedAt: new Date().toISOString(),
          status: 'confirmed'
        };
        const existingTrips: StoredTrip[] = JSON.parse(localStorage.getItem('et_trips') || '[]');
        localStorage.setItem('et_trips', JSON.stringify([...existingTrips, newTrip]));
      }

      setIsProcessing(false);
      setIsSuccess(true);
      window.scrollTo(0, 0);
    }, 2500);
  };

  const applyPromoCode = () => {
    setPromoError('');
    if (promoCode.trim().toUpperCase() === 'MU15') {
      setAppliedPromo(true);
      setPromoError('');
    } else {
      setAppliedPromo(false);
      setPromoError('Invalid promo code');
    }
  };

  if (isSuccess) {
    return (
      <main className="min-h-screen pt-40 pb-20 px-8 flex items-center justify-center bg-surface-container-lowest">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-lg"
        >
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-10 text-primary">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h1 className="text-5xl font-black text-on-surface mb-6 tracking-tighter">{t.checkout.successHead}</h1>
          <p className="text-xl text-on-surface-variant font-medium leading-relaxed mb-12 opacity-60">
            {t.checkout.successSub}
          </p>
          <div className="bg-surface-container-low p-8 rounded-3xl border border-outline-variant/10 mb-12 text-left">
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-on-surface-variant mb-4">Protocol ID</p>
            <p className="font-mono text-2xl font-black text-on-surface tracking-widest break-all">ET-992-QX-441-A</p>
          </div>
          <button 
            onClick={onConfirm}
            className="px-12 py-5 bg-on-surface text-on-primary rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-2xl active:scale-95 transition-all"
          >
            My Trips
          </button>
        </motion.div>
      </main>
    );
  }

  return (
    <main className="pt-24 pb-32 max-w-7xl mx-auto px-8 min-h-screen">
      <AnimatePresence>
        {showPromoPopup && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-8 right-8 z-[100] max-w-sm"
          >
            <div className="bg-primary text-on-primary p-8 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
              <button 
                onClick={() => setShowPromoPopup(false)}
                className="absolute top-4 right-4 text-on-primary/60 hover:text-on-primary transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="relative z-10">
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-black tracking-tighter mb-2">Exclusive Offer!</h3>
                <p className="text-sm font-medium opacity-90 leading-relaxed mb-6">
                  Congratulations! You received a 15% discount for Easy Travel launch 🎉
                </p>
                <div className="flex items-center gap-3">
                  <div className="bg-white/20 border border-white/30 px-5 py-3 rounded-xl font-mono text-xl font-black tracking-widest">
                    MU15
                  </div>
                  <button 
                    onClick={() => {
                      setPromoCode('MU15');
                      setAppliedPromo(true);
                      setPromoError('');
                      setShowPromoPopup(false);
                    }}
                    className="bg-white text-primary px-5 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-opacity-90 transition-all active:scale-95"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row gap-16">
        <div className="flex-1">
          <header className="mb-16">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 text-primary mb-4">
              <Lock className="w-5 h-5" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em]">{(t.checkout.processing || '').split(' ')[0]} SECURE</span>
            </motion.div>
            <h1 className="text-6xl font-black text-on-surface tracking-tighter leading-none">{t.checkout.title}</h1>
          </header>

          <form onSubmit={handleConfirm} className="space-y-16">
            <section>
              <h2 className="text-sm font-black uppercase tracking-[0.3em] text-on-surface-variant mb-8">{t.checkout.payment}</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { id: 'card', name: 'Secure Card', icon: <CreditCard className="w-5 h-5" /> },
                  { id: 'apple', name: 'Apple Pay', icon: <Globe className="w-5 h-5" /> },
                  { id: 'google', name: 'Google Pay', icon: <Globe className="w-5 h-5" /> }
                ].map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setPaymentMethod(method.id as any)}
                    className={cn(
                      "flex items-center gap-4 p-6 rounded-2xl border transition-all active:scale-95",
                      paymentMethod === method.id 
                        ? "bg-white border-primary border-2 shadow-md ring-4 ring-primary/5" 
                        : "bg-surface-container-low border-outline-variant/10 hover:border-outline-variant/40"
                    )}
                  >
                    <div className={cn("text-primary", paymentMethod === method.id ? "opacity-100" : "opacity-40")}>{method.icon}</div>
                    <span className="font-bold text-sm text-on-surface">{method.name}</span>
                  </button>
                ))}
              </div>
            </section>

            {paymentMethod === 'card' && (
              <motion.section 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black tracking-widest text-on-surface-variant opacity-60">Cardholder Name</label>
                  <input 
                    required 
                    className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl px-6 py-5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-20" 
                    placeholder="JOHN A. DOE"
                    value={cardInfo.name}
                    onChange={(e) => setCardInfo({...cardInfo, name: e.target.value.toUpperCase()})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black tracking-widest text-on-surface-variant opacity-60">Card Number</label>
                  <div className="relative group">
                    <input 
                      required 
                      maxLength={19}
                      className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl px-6 py-5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-black text-xl tabular-nums placeholder:opacity-10" 
                      placeholder="0000 0000 0000 0000"
                      value={cardInfo.number}
                      onChange={handleCardNumberChange}
                    />
                    <CreditCard className="absolute right-6 top-1/2 -translate-y-1/2 w-6 h-6 text-outline-variant" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-black tracking-widest text-on-surface-variant opacity-60">Expiry (MM/YY)</label>
                    <input 
                      required 
                      className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl px-6 py-5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold tabular-nums" 
                      placeholder="MM/YY"
                      value={cardInfo.expiry}
                      onChange={handleExpiryChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-black tracking-widest text-on-surface-variant opacity-60">CVV</label>
                    <div className="relative">
                      <input 
                        required 
                        maxLength={4}
                        className="w-full bg-surface-container-low border border-outline-variant/10 rounded-2xl px-6 py-5 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold tabular-nums" 
                        placeholder="***"
                        value={cardInfo.cvv}
                        onChange={(e) => setCardInfo({...cardInfo, cvv: e.target.value})}
                      />
                      <Lock className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-outline-variant" />
                    </div>
                  </div>
                </div>
              </motion.section>
            )}

            <section>
              <h2 className="text-sm font-black uppercase tracking-[0.3em] text-on-surface-variant mb-8">{t.checkout.installment}</h2>
              
              <div className="flex gap-4 mb-8">
                {[
                  { id: 'full', label: 'Pay in Full' },
                  { id: 'installments', label: 'Installments' }
                ].map((mode) => (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setPaymentMode(mode.id as any)}
                    className={cn(
                      "flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest border transition-all cursor-pointer",
                      paymentMode === mode.id
                        ? "bg-primary text-on-primary border-primary shadow-lg"
                        : "bg-surface-container-low border-outline-variant/10 text-on-surface-variant hover:border-outline-variant/40"
                    )}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>

              <AnimatePresence>
                {paymentMode === 'installments' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: 'auto' }}
                    exit={{ opacity: 0, y: 10, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-surface-container-low p-2 rounded-2xl border border-outline-variant/5 flex gap-2">
                      {[3, 6, 12].map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setInstallmentPlan(m)}
                          className={cn(
                            "flex-1 p-5 rounded-xl transition-all font-bold text-center",
                            installmentPlan === m 
                              ? "bg-white text-primary shadow-sm border border-outline-variant/10" 
                              : "text-on-surface-variant opacity-50 hover:opacity-100 hover:bg-surface-container-highest/20"
                          )}
                        >
                          <p className="text-sm border-b border-outline-variant/10 pb-2 mb-2">{m} Months</p>
                          <p className="text-[9px] uppercase tracking-widest leading-none mt-1">
                            {formatPrice(finalTotal / m)}/mo
                          </p>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </section>
          </form>
        </div>

        <aside className="w-full lg:w-96">
          <div className="sticky top-28 space-y-8 bg-surface-container-low p-10 rounded-[2.5rem] border border-outline-variant/10 shadow-xl">
            <h2 className="text-2xl font-black tracking-tighter text-on-surface mb-10">{t.checkout.fare}</h2>
            
            <div className="space-y-6">
              <div className="flex justify-between items-center text-sm">
                <span className="text-on-surface-variant font-medium opacity-60">{t.checkout.base}</span>
                <span className="font-bold text-on-surface">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-on-surface-variant font-medium opacity-60">{t.checkout.taxes}</span>
                <span className="font-bold text-on-surface">{formatPrice(taxesAmount)}</span>
              </div>
              {appliedPromo && (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }} 
                  animate={{ opacity: 1, x: 0 }}
                  className="flex justify-between items-center text-sm text-primary bg-primary/5 p-4 rounded-xl border border-primary/10"
                >
                  <div className="flex flex-col">
                    <span className="font-black">MU15 applied</span>
                    <span className="text-[10px] opacity-70">15% Discount Protocol</span>
                  </div>
                  <span className="font-black">-{formatPrice(discountAmount)}</span>
                </motion.div>
              )}
              
              <div className="pt-8 border-t border-outline-variant/10 mt-10">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-on-surface-variant opacity-40 mb-2">{t.checkout.grandTotal}</span>
                  <div className="flex justify-between items-end">
                    <span className="text-5xl font-black text-on-surface tracking-tighter tabular-nums">{formatPrice(finalTotal)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-10">
              <div className="relative group">
                <Sparkles className={cn(
                  "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors",
                  appliedPromo ? "text-primary" : "text-outline-variant group-focus-within:text-primary"
                )} />
                <input 
                  className={cn(
                    "w-full bg-surface-container-lowest border rounded-2xl py-4.5 pl-14 pr-6 focus:ring-4 focus:ring-primary/10 outline-none transition-all font-bold placeholder:opacity-30 text-sm uppercase",
                    appliedPromo ? "border-primary" : "border-outline-variant/10",
                    promoError ? "border-tertiary" : ""
                  )}
                  placeholder={t.checkout.promo}
                  value={promoCode}
                  onChange={(e) => {
                    setPromoCode(e.target.value.toUpperCase());
                    setPromoError('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      applyPromoCode();
                    }
                  }}
                />
              </div>
              {promoError && (
                <motion.p 
                  initial={{ opacity: 0, y: -5 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  className="text-[10px] text-tertiary font-black uppercase mt-2 ml-2 tracking-widest"
                >
                  {promoError}
                </motion.p>
              )}
            </div>

            <div className="pt-10 flex items-start gap-4 p-5 bg-surface-container-lowest rounded-2xl border border-outline-variant/10 opacity-70">
              <Lock className="w-5 h-5 text-primary shrink-0 mt-1" />
              <p className="text-[10px] uppercase font-black text-on-surface-variant leading-relaxed tracking-widest">
                Protocol Secured with AES-256 and RSA-4096 Encryption standards for complete data sovereignty.
              </p>
            </div>
          </div>
        </aside>
      </div>

      <div className="mt-16 pt-16 border-t border-outline-variant/5">
        <button 
          onClick={handleConfirm}
          disabled={isProcessing}
          className="w-full py-8 bg-primary text-on-primary rounded-[2.5rem] font-black text-2xl shadow-2xl hover:translate-y-[-8px] hover:shadow-primary/20 active:scale-[0.98] transition-all flex items-center justify-center gap-6 disabled:opacity-50 group"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-8 h-8 animate-spin" /> 
              <span>Synchronizing Protocols...</span>
            </>
          ) : (
            <>
              <span>{t.checkout.confirm}</span>
              <div className="w-12 h-12 bg-on-primary/10 rounded-full flex items-center justify-center group-hover:bg-on-primary/20 transition-all">
                <ArrowRight className="w-6 h-6" />
              </div>
            </>
          )}
        </button>
        <p className="text-center mt-8 text-on-surface-variant font-black uppercase tracking-[0.4em] text-[10px] opacity-20">
          Authorization Secured with PCI-DSS Protocol v4.0
        </p>
      </div>
    </main>
  );
}
