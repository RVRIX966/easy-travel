export interface SearchFilters {
  departure: string;
  destination?: string;
  tripType: 'one-way' | 'round-trip';
  departureDate: string;
  returnDate?: string;
  passengers: number;
  cabinClass: 'economy' | 'premium' | 'business' | 'first';
  budget: number;
  nationality: string;
  preferences: string[];
}

export interface StopDetail {
  location: string;
  duration: string;
}

export interface Flight {
  id: string;
  airline: string;
  code: string;
  class: string;
  price: number;
  departure: string;
  departureTime: string;
  depCode: string;
  arrival: string;
  arrivalTime: string;
  arrCode: string;
  duration: string;
  stops: number;
  stopDetails?: StopDetail[];
  logo?: string;
}

export interface RoomType {
  id: string;
  name: string;
  priceMultiplier: number;
  description: string;
  images?: string[];
}

export interface Hotel {
  id: string;
  name: string;
  location: string;
  distance?: number;
  rating: number;
  stars: number;
  price: number;
  images: string[];
  desc: string;
  amenities: string[];
  tag?: string;
  roomTypes?: RoomType[];
}

export interface Destination {
  id: number;
  name: string;
  image: string;
  type: string;
  price: number;
  visa: {
    type: string;
    cost: number;
    time: string;
  };
  isFeatured?: boolean;
  tags: string[];
  desc?: string;
  recommendedFlights?: Flight[];
  recommendedHotels?: Hotel[];
}

export interface BookingSummary {
  flight: Flight | null;
  hotel: Hotel | null;
  room: RoomType | null;
  passengers: number;
  roomCount: number;
  nights: number;
  checkInDate: string;
  checkOutDate: string;
  breakfast: boolean;
  totalPrice: number;
  taxes: number;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  joinedAt: string;
}

export interface StoredTrip extends BookingSummary {
  id: string;
  userId: string;
  bookedAt: string;
  status: 'confirmed' | 'pending' | 'cancelled';
}
