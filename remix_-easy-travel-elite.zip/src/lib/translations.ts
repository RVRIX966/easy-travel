export const translations = {
  en: {
    nav: {
      destinations: 'Destinations',
      itineraries: 'Itineraries',
      support: 'Support',
      login: 'Login',
      signup: 'Sign Up'
    },
    home: {
      heroTitle: 'Plan your dream trip',
      heroSubtitle: 'within your budget.',
      heroDesc: 'Experience the world without the noise. Intelligent itineraries curated for your lifestyle and wallet.',
      budgetLabel: 'Total Budget',
      nationalityLabel: 'Nationality',
      prefsLabel: 'Travel Preferences',
      searchBtn: 'Search Destinations',
      searching: 'Optimizing Journey...',
      featuredTitle: 'Curated Escapes',
      featuredDesc: 'Handpicked destinations matching current travel trends.',
      viewAll: 'View All Destinations'
    },
    destinations: {
      title: 'Curated Escapes Within Reach.',
      desc: 'Refining travel by the absence of noise. Discover hand-picked destinations that align with your vision and budget.',
      maxBudget: 'Max Budget',
      season: 'Season',
      loading: 'Recalculating Itineraries...',
      noResults: 'No journeys match current constraints.',
      resetFilters: 'Reset Filters'
    },
    auth: {
      loginTitle: 'Welcome back',
      loginDesc: 'Access your curated itineraries and travel preferences.',
      signupTitle: 'Start your journey',
      signupDesc: 'Join Easy Travel for personalized itineraries and exclusive deals.',
      email: 'Email Address',
      password: 'Password',
      forgotPassword: 'Forgot Password?',
      loginBtn: 'Sign In',
      signupBtn: 'Create Account',
      orSocial: 'Or continue with',
      noAccount: "Don't have an account?",
      hasAccount: 'Already have an account?'
    },
    support: {
      title: 'Care center.',
      desc: 'Your peace of mind is our highest priority. Connect with our concierge or explore our intelligence base.',
      formTitle: 'Send a Message',
      nameLabel: 'Name',
      emailLabel: 'Email',
      messageLabel: 'Message',
      sendBtn: 'Send Message',
      transmitting: 'Transmitting...',
      sentHead: 'Message Dispatched',
      sentSub: 'An expert concierge will reply within 30 minutes.',
      sendAnother: 'Send another message',
      faqTitle: 'Common Intelligence',
      chat: 'Live Concierge Chat',
      chatSub: 'Average response: 2 mins',
      phone: '+1 (888) TRAVEL-EASY',
      phoneSub: '24/7 Priority Support'
    },
    itinerary: {
      title: 'Journey Architecture.',
      summary: 'Trip Summary',
      flights: 'Flights',
      hotels: 'Refined Stays',
      total: 'Estimated Total',
      confirm: 'Continue to Checkout',
      perPerson: 'per person',
      selected: 'Selected'
    },
    checkout: {
      title: 'Final Protocol.',
      payment: 'Payment Method',
      installment: 'Flexible Installments',
      promo: 'Promotion Code',
      fare: 'Fare Breakdown',
      base: 'Base Fare',
      taxes: 'Taxes & Fees',
      discount: 'Protocols Discount',
      grandTotal: 'Grand Total',
      confirm: 'Confirm & Synchronize',
      processing: 'Synchronizing Protocol...',
      successHead: 'Journey Synchronized',
      successSub: 'Your itineraries and protocols have been successfully established.'
    }
  },
  ar: {
    nav: {
      destinations: 'الوجهات',
      itineraries: 'المخططات',
      support: 'الدعم',
      login: 'تسجيل الدخول',
      signup: 'إنشاء حساب'
    },
    home: {
      heroTitle: 'خطط لرحلة أحلامك',
      heroSubtitle: 'ضمن ميزانيتك.',
      heroDesc: 'اكتشف العالم دون ضجيج. مسارات ذكية منسقة لأسلوب حياتك وميزانيتك.',
      budgetLabel: 'الميزانية الإجمالية',
      nationalityLabel: 'الجنسية',
      prefsLabel: 'تفضيلات السفر',
      searchBtn: 'البحث عن الوجهات',
      searching: 'تحسين المسار...',
      featuredTitle: 'هروب منسق',
      featuredDesc: 'وجهات مختارة بعناية تواكب اتجاهات السفر الحالية.',
      viewAll: 'عرض جميع الوجهات'
    },
    destinations: {
      title: 'هروب منسق في متناول اليد.',
      desc: 'تحسين السفر من خلال غياب الضوضاء. اكتشف الوجهات المختارة بعناية والتي تتوافق مع رؤيتك وميزانيتك.',
      maxBudget: 'الميزانية القصوى',
      season: 'الموسم',
      loading: 'إعادة حساب المسارات...',
      noResults: 'لا توجد رحلات تطابق الشروط الحالية.',
      resetFilters: 'إعادة ضبط الفلاتر'
    },
    auth: {
      loginTitle: 'مرحباً بعودتك',
      loginDesc: 'الوصول إلى مساراتك المنسقة وتفضيلات السفر.',
      signupTitle: 'ابدأ رحلتك',
      signupDesc: 'انضم إلى Easy Travel للحصول على مسارات مخصصة وعروض حصرية.',
      email: 'البريد الإلكتروني',
      password: 'كلمة مرور',
      forgotPassword: 'نسيت كلمة المرور؟',
      loginBtn: 'تسجيل الدخول',
      signupBtn: 'إنشاء حساب',
      orSocial: 'أو الاستمرار بواسطة',
      noAccount: 'ليس لديك حساب؟',
      hasAccount: 'لديك حساب بالفعل؟'
    },
    support: {
      title: 'مركز الرعاية.',
      desc: 'راحتك هي أولويتنا القصوى. تواصل مع خدمات الكونسيرج لدينا أو استكشف قاعدة معلوماتنا.',
      formTitle: 'إرسال رسالة',
      nameLabel: 'الاسم',
      emailLabel: 'البريد الإلكتروني',
      messageLabel: 'الرسالة',
      sendBtn: 'إرسال الرسالة',
      transmitting: 'جاري الإرسال...',
      sentHead: 'تم إرسال الرسالة',
      sentSub: 'سيقوم خبير كونسيرج بالرد في غضون 30 دقيقة.',
      sendAnother: 'إرسال رسالة أخرى',
      faqTitle: 'الأسئلة الشائعة',
      chat: 'دردشة حية',
      chatSub: 'متوسط الرد: دقيقتان',
      phone: '+1 (888) TRAVEL-EASY',
      phoneSub: 'دعم ذو أولوية 24/7'
    },
    itinerary: {
      title: 'بنية الرحلة.',
      summary: 'ملخص الرحلة',
      flights: 'الرحلات الجوية',
      hotels: 'فنادق مميزة',
      total: 'الإجمالي التقديري',
      confirm: 'المتابعة للدفع',
      perPerson: 'لكل شخص',
      selected: 'تم الاختيار'
    },
    checkout: {
      title: 'البروتوكول النهائي.',
      payment: 'طريقة الدفع',
      installment: 'أقساط مرنة',
      promo: 'كود خصم',
      fare: 'تفاصيل السعر',
      base: 'السعر الأساسي',
      taxes: 'الضرائب والرسوم',
      discount: 'خصم البروتوكول',
      grandTotal: 'الإجمالي الكلي',
      confirm: 'تأكيد ومزامنة',
      processing: 'جاري مزامنة البروتوكول...',
      successHead: 'تمت مزامنة الرحلة',
      successSub: 'تم إنشاء مساراتك وبروتوكولاتك بنجاح.'
    }
  }
};

export type Language = 'en' | 'ar';
export type TranslationKey = typeof translations.en;
